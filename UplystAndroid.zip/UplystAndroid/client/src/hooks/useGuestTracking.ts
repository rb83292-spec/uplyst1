import { useState, useEffect } from "react";
import { nanoid } from "nanoid";

interface GuestTracking {
  guestId: string;
  reactionCount: number;
  commentCount: number;
  reactions: Record<string, string>;
}

const STORAGE_KEY = "uplyst_guest_tracking";
const MAX_GUEST_COMMENTS = 1;

function getGuestTracking(): GuestTracking {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch {
      return createNewGuestTracking();
    }
  }
  return createNewGuestTracking();
}

function createNewGuestTracking(): GuestTracking {
  return {
    guestId: nanoid(),
    reactionCount: 0,
    commentCount: 0,
    reactions: {},
  };
}

function saveGuestTracking(tracking: GuestTracking) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tracking));
}

export function useGuestTracking() {
  const [tracking, setTracking] = useState<GuestTracking>(getGuestTracking());

  useEffect(() => {
    saveGuestTracking(tracking);
  }, [tracking]);

  const addReaction = (entryId: string, reactionType: string): boolean => {
    const existingReaction = tracking.reactions[entryId];
    
    if (existingReaction === reactionType) {
      return false;
    }

    const newReactionCount = existingReaction 
      ? tracking.reactionCount 
      : tracking.reactionCount + 1;

    setTracking({
      ...tracking,
      reactionCount: newReactionCount,
      reactions: {
        ...tracking.reactions,
        [entryId]: reactionType,
      },
    });

    return true;
  };

  const removeReaction = (entryId: string): boolean => {
    if (!tracking.reactions[entryId]) {
      return false;
    }

    const newReactions = { ...tracking.reactions };
    delete newReactions[entryId];

    setTracking({
      ...tracking,
      reactionCount: tracking.reactionCount - 1,
      reactions: newReactions,
    });

    return true;
  };

  const canAddReaction = (entryId: string): boolean => {
    return true;
  };

  const getReaction = (entryId: string): string | null => {
    return tracking.reactions[entryId] || null;
  };

  const incrementCommentCount = () => {
    setTracking({
      ...tracking,
      commentCount: tracking.commentCount + 1,
    });
  };

  const canAddComment = (): boolean => {
    return tracking.commentCount < MAX_GUEST_COMMENTS;
  };

  const clearTracking = () => {
    localStorage.removeItem(STORAGE_KEY);
    setTracking(createNewGuestTracking());
  };

  return {
    guestId: tracking.guestId,
    reactionCount: tracking.reactionCount,
    commentCount: tracking.commentCount,
    canAddReaction,
    canAddComment,
    addReaction,
    removeReaction,
    getReaction,
    incrementCommentCount,
    clearTracking,
  };
}
