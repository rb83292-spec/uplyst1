import { cn } from "@/lib/utils";

interface ListCoverBannerProps {
  title: string;
  category: string;
  imageUrl?: string;
  className?: string;
}

const categoryGradients: Record<string, string> = {
  Music: "linear-gradient(135deg, rgb(147 51 234) 0%, rgb(219 39 119) 50%, rgb(249 115 22) 100%)",
  Movies: "linear-gradient(135deg, rgb(37 99 235) 0%, rgb(79 70 229) 50%, rgb(147 51 234) 100%)",
  Artists: "linear-gradient(135deg, rgb(225 29 72) 0%, rgb(236 72 153) 50%, rgb(192 38 211) 100%)",
  Streaming: "linear-gradient(135deg, rgb(8 145 178) 0%, rgb(59 130 246) 50%, rgb(79 70 229) 100%)",
  Shopping: "linear-gradient(135deg, rgb(5 150 105) 0%, rgb(20 184 166) 50%, rgb(6 182 212) 100%)",
  Tech: "linear-gradient(135deg, rgb(51 65 85) 0%, rgb(75 85 99) 50%, rgb(82 82 91) 100%)",
};

export default function ListCoverBanner({ 
  title, 
  category, 
  imageUrl, 
  className 
}: ListCoverBannerProps) {
  const gradient = categoryGradients[category] || categoryGradients.Tech;
  
  return (
    <div 
      className={cn(
        "relative w-full h-48 md:h-64 rounded-lg overflow-hidden mb-6",
        className
      )}
      data-testid="list-cover-banner"
      style={!imageUrl ? { backgroundImage: gradient } : undefined}
    >
      {imageUrl && (
        <img 
          src={imageUrl} 
          alt={title}
          className="w-full h-full object-cover"
        />
      )}
      
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{ 
          backgroundImage: "linear-gradient(to top, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0.4) 50%, transparent 100%)" 
        }}
      />
      
      <div className="absolute bottom-0 left-0 right-0 p-6 md:p-8 z-10">
        <h1 
          className="text-3xl md:text-4xl lg:text-5xl font-bold text-white drop-shadow-lg"
          data-testid="text-banner-title"
          style={{ fontFamily: 'Inter, system-ui, sans-serif' }}
        >
          {title}
        </h1>
      </div>
    </div>
  );
}
