import { Gem, Lightbulb } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface Reaction {
  type: "underrated" | "overhyped";
  count: number;
  userReacted?: boolean;
}

interface EntryReactionsProps {
  reactions: Reaction[];
  onReact?: (type: Reaction["type"]) => void;
  size?: "sm" | "md";
}

const reactionConfig = {
  underrated: {
    icon: Gem,
    label: "Underrated",
    color: "text-cyan-500",
    bgColor: "bg-cyan-50 dark:bg-cyan-950/20",
  },
  overhyped: {
    icon: Lightbulb,
    label: "Overhyped",
    color: "text-yellow-500",
    bgColor: "bg-yellow-50 dark:bg-yellow-950/20",
  },
};

export default function EntryReactions({ reactions, onReact, size = "md" }: EntryReactionsProps) {
  const sizeClasses = size === "sm" ? "h-3.5 w-3.5" : "h-4 w-4";

  return (
    <div className="flex flex-wrap gap-2" data-testid="entry-reactions">
      {reactions.map((reaction) => {
        const config = reactionConfig[reaction.type];
        const Icon = config.icon;
        
        return (
          <Badge
            key={reaction.type}
            variant={reaction.userReacted ? "default" : "secondary"}
            className={cn(
              "gap-1.5 cursor-pointer transition-all",
              !reaction.userReacted && config.bgColor,
              reaction.userReacted && "bg-primary text-primary-foreground"
            )}
            onClick={() => onReact?.(reaction.type)}
            data-testid={`reaction-${reaction.type}`}
          >
            <Icon className={cn(sizeClasses, !reaction.userReacted && config.color)} />
            <span className={cn("text-xs font-medium", !reaction.userReacted && "text-foreground")}>
              {config.label}
            </span>
            {reaction.count > 0 && (
              <span className="text-xs font-bold">
                {reaction.count}
              </span>
            )}
          </Badge>
        );
      })}
    </div>
  );
}
