import { Flame } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function TrendingBadge() {
  return (
    <Badge className="bg-trending text-trending-foreground border-0 gap-1" data-testid="badge-trending">
      <Flame className="h-3 w-3" />
      Trending
    </Badge>
  );
}
