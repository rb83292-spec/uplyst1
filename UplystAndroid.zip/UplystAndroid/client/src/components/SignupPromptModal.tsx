import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Sparkles, Heart, Star } from "lucide-react";

interface SignupPromptModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  reason: "rate" | "save" | "comment" | "follow" | "create";
}

const promptConfig = {
  rate: {
    icon: Star,
    title: "Save your taste",
    description: "Sign up to rate unlimited items and build your personal profile. It only takes a moment!",
  },
  save: {
    icon: Heart,
    title: "Save your favorites",
    description: "Create an account to save lists and build your collection. Never lose track of what you love!",
  },
  comment: {
    icon: Sparkles,
    title: "Join the conversation",
    description: "Sign up to share your thoughts and connect with the community. Your voice matters!",
  },
  follow: {
    icon: Heart,
    title: "Follow creators you love",
    description: "Create an account to follow curators and stay updated with their latest lists!",
  },
  create: {
    icon: Sparkles,
    title: "Share your expertise",
    description: "Sign up to create and publish your own curated lists. Show the world your taste!",
  },
};

export default function SignupPromptModal({
  open,
  onOpenChange,
  reason,
}: SignupPromptModalProps) {
  const config = promptConfig[reason];
  const Icon = config.icon;

  const handleSignup = () => {
    window.location.href = "/api/login";
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]" data-testid="modal-signup-prompt">
        <DialogHeader>
          <div className="flex items-center justify-center mb-4">
            <div className="bg-primary/10 p-3 rounded-full">
              <Icon className="h-6 w-6 text-primary" />
            </div>
          </div>
          <DialogTitle className="text-center" data-testid="text-prompt-title">
            {config.title}
          </DialogTitle>
          <DialogDescription className="text-center" data-testid="text-prompt-description">
            {config.description}
          </DialogDescription>
        </DialogHeader>

        <DialogFooter className="flex-col sm:flex-col gap-2">
          <Button
            onClick={handleSignup}
            className="w-full"
            data-testid="button-signup"
          >
            Sign up with Replit
          </Button>
          <Button
            variant="ghost"
            onClick={() => onOpenChange(false)}
            className="w-full"
            data-testid="button-continue-browsing"
          >
            Continue browsing
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
