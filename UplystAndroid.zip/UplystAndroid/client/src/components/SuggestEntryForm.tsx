import { useState } from "react";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

interface SuggestEntryFormProps {
  listId: string;
  listTitle: string;
  onSubmit: (suggestion: {
    title: string;
    description: string;
    imageUrl?: string;
    externalUrl?: string;
    embedUrl?: string;
  }) => void;
  isAuthenticated: boolean;
}

export default function SuggestEntryForm({
  listId,
  listTitle,
  onSubmit,
  isAuthenticated,
}: SuggestEntryFormProps) {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [externalUrl, setExternalUrl] = useState("");
  const [embedUrl, setEmbedUrl] = useState("");
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim() || !description.trim()) {
      toast({
        title: "Missing information",
        description: "Please provide both a title and description.",
        variant: "destructive",
      });
      return;
    }

    onSubmit({
      title: title.trim(),
      description: description.trim(),
      imageUrl: imageUrl.trim() || undefined,
      externalUrl: externalUrl.trim() || undefined,
      embedUrl: embedUrl.trim() || undefined,
    });

    setTitle("");
    setDescription("");
    setImageUrl("");
    setExternalUrl("");
    setEmbedUrl("");
    setOpen(false);

    toast({
      title: "Suggestion submitted",
      description: "The curator will review your suggestion within 7 days.",
    });
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2" data-testid="button-suggest-entry">
          <Plus className="h-4 w-4" />
          Suggest Entry
        </Button>
      </DialogTrigger>

      <DialogContent className="sm:max-w-[500px]" data-testid="modal-suggest-entry">
        <DialogHeader>
          <DialogTitle>Suggest an Entry</DialogTitle>
          <DialogDescription>
            Suggest a new item for "{listTitle}". The curator will review it within 7 days.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              placeholder="Entry title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              data-testid="input-suggestion-title"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              placeholder="Why should this be included?"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              data-testid="input-suggestion-description"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="imageUrl">Image URL (optional)</Label>
            <Input
              id="imageUrl"
              type="url"
              placeholder="https://..."
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              data-testid="input-suggestion-image"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="externalUrl">External Link (optional)</Label>
            <Input
              id="externalUrl"
              type="url"
              placeholder="https://..."
              value={externalUrl}
              onChange={(e) => setExternalUrl(e.target.value)}
              data-testid="input-suggestion-external"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="embedUrl">Embed URL (optional)</Label>
            <Input
              id="embedUrl"
              type="url"
              placeholder="https://open.spotify.com/embed/..."
              value={embedUrl}
              onChange={(e) => setEmbedUrl(e.target.value)}
              data-testid="input-suggestion-embed"
            />
            <p className="text-xs text-muted-foreground">
              For Spotify, YouTube, or SoundCloud embeds
            </p>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" data-testid="button-submit-suggestion">
              Submit Suggestion
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
