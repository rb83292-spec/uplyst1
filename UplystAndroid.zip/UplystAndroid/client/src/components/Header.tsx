import { Search, User, Menu, Plus } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Logo from "./Logo";
import { useState, KeyboardEvent } from "react";

interface HeaderProps {
  onAuthClick?: () => void;
  onMenuClick?: () => void;
  onCreateListClick?: () => void;
  isAuthenticated?: boolean;
}

export default function Header({ onAuthClick, onMenuClick, onCreateListClick, isAuthenticated = false }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [, navigate] = useLocation();

  const handleSearch = () => {
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const handleKeyPress = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background">
      <div className="flex h-16 items-center gap-4 px-4 md:px-8">
        <Button
          size="icon"
          variant="ghost"
          className="md:hidden"
          onClick={onMenuClick}
          data-testid="button-menu"
        >
          <Menu className="h-5 w-5" />
        </Button>
        
        <Link href="/" className="flex items-center" data-testid="link-home">
          <Logo size="sm" showText={true} />
        </Link>

        <div className="flex-1 max-w-2xl mx-auto hidden md:flex">
          <div className="relative w-full flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search lists..."
                className="pl-9 rounded-full"
                data-testid="input-search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={handleKeyPress}
              />
            </div>
            <Button 
              onClick={handleSearch} 
              size="icon" 
              variant="default"
              data-testid="button-search"
              className="rounded-full"
            >
              <Search className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {isAuthenticated && (
            <Button
              variant="default"
              onClick={onCreateListClick}
              className="gap-2"
              data-testid="button-create-list"
            >
              <Plus className="h-4 w-4" />
              <span className="hidden sm:inline">Create List</span>
            </Button>
          )}
          {isAuthenticated ? (
            <Button
              size="icon"
              variant="ghost"
              onClick={onAuthClick}
              data-testid="button-profile"
            >
              <User className="h-5 w-5" />
            </Button>
          ) : (
            <Button
              variant="default"
              onClick={onAuthClick}
              data-testid="button-signin"
            >
              Sign In
            </Button>
          )}
        </div>
      </div>

      <div className="md:hidden px-4 pb-2">
        <div className="relative w-full flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search lists..."
              className="pl-9 rounded-full"
              data-testid="input-search-mobile"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={handleKeyPress}
            />
          </div>
          <Button 
            onClick={handleSearch} 
            size="icon" 
            variant="default"
            data-testid="button-search-mobile"
            className="rounded-full"
          >
            <Search className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  );
}
