import { User, Hash } from "lucide-react";
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import TrendingBadge from "./TrendingBadge";
import VoteButtons from "./VoteButtons";

interface ListCardProps {
  id: string;
  title: string;
  description: string;
  creator: string;
  createdAt: string;
  category: string;
  entryCount: number;
  votes: number;
  isTrending?: boolean;
  thumbnail?: string;
  onClick?: () => void;
}

export default function ListCard({
  id,
  title,
  description,
  creator,
  createdAt,
  category,
  entryCount,
  votes,
  isTrending = false,
  thumbnail,
  onClick,
}: ListCardProps) {
  return (
    <Card className="hover-elevate cursor-pointer relative overflow-hidden" onClick={onClick} data-testid={`card-list-${id}`}>
      {isTrending && (
        <div className="absolute top-4 right-4 z-10">
          <TrendingBadge />
        </div>
      )}
      
      <CardHeader className="gap-3">
        <div className="flex gap-4">
          <div className="flex-shrink-0">
            <VoteButtons initialVotes={votes} onVote={(voted) => console.log('List voted:', voted)} />
          </div>
          
          <div className="flex-1 min-w-0">
            {thumbnail && (
              <div className="w-full aspect-video rounded-lg overflow-hidden mb-3 bg-muted">
                <img src={thumbnail} alt={title} className="w-full h-full object-cover" />
              </div>
            )}
            
            <div className="flex items-start gap-2 mb-2">
              <Badge variant="secondary" className="text-xs" data-testid={`badge-category-${category}`}>
                {category}
              </Badge>
            </div>
            
            <h3 className="text-xl font-bold mb-2 line-clamp-2" data-testid="text-list-title">
              {title}
            </h3>
            
            <p className="text-sm text-muted-foreground line-clamp-2 mb-3" data-testid="text-list-description">
              {description}
            </p>
          </div>
        </div>
      </CardHeader>

      <CardFooter className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
        <div className="flex items-center gap-1">
          <User className="h-3 w-3" />
          <span data-testid="text-creator">{creator}</span>
        </div>
        
        <div className="flex items-center gap-1">
          <Hash className="h-3 w-3" />
          <span data-testid="text-entry-count">{entryCount} entries</span>
        </div>
        
        <span className="text-xs" data-testid="text-created-at">{createdAt}</span>
      </CardFooter>
    </Card>
  );
}
