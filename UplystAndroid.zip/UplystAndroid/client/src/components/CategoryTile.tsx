import { LucideIcon } from "lucide-react";
import { Card } from "@/components/ui/card";

interface CategoryTileProps {
  name: string;
  count: number;
  backgroundImage: string;
  icon: LucideIcon;
  onClick?: () => void;
}

export default function CategoryTile({ name, count, backgroundImage, icon: Icon, onClick }: CategoryTileProps) {
  return (
    <Card
      className="relative overflow-hidden cursor-pointer group hover-elevate active-elevate-2 h-40 md:h-48"
      onClick={onClick}
      data-testid={`card-category-${name.toLowerCase()}`}
    >
      <div
        className="absolute inset-0 bg-cover bg-center transition-transform group-hover:scale-105"
        style={{ backgroundImage: `url(${backgroundImage})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/20" />
      
      <div className="relative h-full flex flex-col items-center justify-center text-white p-6">
        <Icon className="h-10 w-10 mb-3" />
        <h3 className="text-2xl font-bold mb-1">{name}</h3>
        <p className="text-sm text-white/80">{count} lists</p>
      </div>
    </Card>
  );
}
