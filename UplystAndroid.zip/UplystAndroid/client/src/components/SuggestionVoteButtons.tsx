import { useState } from "react";
import { ChevronUp, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface SuggestionVoteButtonsProps {
  initialVotes: number;
  userVote?: number;
  onVote?: (voteType: number) => void;
  size?: "sm" | "md";
}

export default function SuggestionVoteButtons({
  initialVotes,
  userVote: initialUserVote = 0,
  onVote,
  size = "md",
}: SuggestionVoteButtonsProps) {
  const [votes, setVotes] = useState(initialVotes);
  const [userVote, setUserVote] = useState(initialUserVote);

  const handleVote = (voteType: number) => {
    if (userVote === voteType) {
      const newVotes = votes - voteType;
      setVotes(newVotes);
      setUserVote(0);
      onVote?.(0);
    } else {
      const voteChange = voteType - userVote;
      const newVotes = votes + voteChange;
      setVotes(newVotes);
      setUserVote(voteType);
      onVote?.(voteType);
    }
  };

  const iconSize = size === "sm" ? "h-4 w-4" : "h-5 w-5";
  const buttonSize = size === "sm" ? "h-7 w-7" : "h-8 w-8";

  return (
    <div className="flex flex-col items-center gap-1" data-testid="suggestion-vote-buttons">
      <Button
        size="icon"
        variant={userVote === 1 ? "default" : "ghost"}
        className={cn(buttonSize)}
        onClick={() => handleVote(1)}
        data-testid="button-upvote-suggestion"
      >
        <ChevronUp className={iconSize} />
      </Button>

      <span
        className={cn(
          "text-base font-bold",
          votes > 0 && "text-green-600 dark:text-green-400",
          votes < 0 && "text-red-600 dark:text-red-400",
          votes === 0 && "text-muted-foreground"
        )}
        data-testid="text-suggestion-votes"
      >
        {votes > 0 && "+"}
        {votes}
      </span>

      <Button
        size="icon"
        variant={userVote === -1 ? "destructive" : "ghost"}
        className={cn(buttonSize)}
        onClick={() => handleVote(-1)}
        data-testid="button-downvote-suggestion"
      >
        <ChevronDown className={iconSize} />
      </Button>
    </div>
  );
}
