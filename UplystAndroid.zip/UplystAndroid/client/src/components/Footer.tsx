import { Link } from "wouter";
import Logo from "./Logo";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t bg-card mt-auto" data-testid="footer">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and tagline */}
          <div className="md:col-span-1">
            <Logo size="sm" showText={true} />
            <p className="text-sm text-muted-foreground mt-3">
              Community-driven rankings across music, movies, tech, and more.
            </p>
          </div>

          {/* Categories */}
          <div>
            <h3 className="font-semibold mb-3" data-testid="text-footer-categories">Categories</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/category/music" className="hover:text-foreground transition-colors" data-testid="link-footer-music">Music</Link></li>
              <li><Link href="/category/movies" className="hover:text-foreground transition-colors" data-testid="link-footer-movies">Movies</Link></li>
              <li><Link href="/category/artists" className="hover:text-foreground transition-colors" data-testid="link-footer-artists">Artists</Link></li>
              <li><Link href="/category/streaming" className="hover:text-foreground transition-colors" data-testid="link-footer-streaming">Streaming</Link></li>
              <li><Link href="/category/shopping" className="hover:text-foreground transition-colors" data-testid="link-footer-shopping">Shopping</Link></li>
              <li><Link href="/category/tech" className="hover:text-foreground transition-colors" data-testid="link-footer-tech">Tech</Link></li>
            </ul>
          </div>

          {/* Community */}
          <div>
            <h3 className="font-semibold mb-3" data-testid="text-footer-community">Community</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/about" className="hover:text-foreground transition-colors" data-testid="link-footer-about">About</Link></li>
              <li><Link href="/guidelines" className="hover:text-foreground transition-colors" data-testid="link-footer-guidelines">Guidelines</Link></li>
              <li><Link href="/moderators" className="hover:text-foreground transition-colors" data-testid="link-footer-moderators">Moderators</Link></li>
              <li><Link href="/faq" className="hover:text-foreground transition-colors" data-testid="link-footer-faq">FAQ</Link></li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="font-semibold mb-3" data-testid="text-footer-legal">Legal</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/terms" className="hover:text-foreground transition-colors" data-testid="link-footer-terms">Terms of Service</Link></li>
              <li><Link href="/privacy" className="hover:text-foreground transition-colors" data-testid="link-footer-privacy">Privacy Policy</Link></li>
              <li><Link href="/contact" className="hover:text-foreground transition-colors" data-testid="link-footer-contact">Contact</Link></li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t mt-8 pt-6 text-center text-sm text-muted-foreground">
          <p data-testid="text-footer-copyright">© {currentYear} Uplyst. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
