import { useState } from "react";
import { MessageCircle, ChevronDown, ChevronUp, ExternalLink } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import RatingStars from "./RatingStars";
import EntryReactions from "./EntryReactions";
import EmbeddedPlayer from "./EmbeddedPlayer";

interface EntryItemProps {
  rank: number;
  title: string;
  description: string;
  thumbnail?: string;
  externalUrl?: string;
  embedUrl?: string;
  rating?: number;
  voteCount?: number;
  commentCount?: number;
  reactions?: Array<{
    type: "underrated" | "overhyped";
    count: number;
    userReacted?: boolean;
  }>;
  onRate?: () => void;
  onComment?: () => void;
  onReact?: (type: "underrated" | "overhyped") => void;
}

export default function EntryItem({
  rank,
  title,
  description,
  thumbnail,
  externalUrl,
  embedUrl,
  rating,
  voteCount,
  commentCount = 0,
  reactions = [],
  onRate,
  onComment,
  onReact,
}: EntryItemProps) {
  const [expanded, setExpanded] = useState(false);
  const [showEmbed, setShowEmbed] = useState(false);

  return (
    <Card 
      className="hover-elevate transition-all duration-200 hover:shadow-lg group" 
      data-testid={`card-entry-${rank}`}
    >
      <div className="p-6">
        <div className="flex gap-6">
          <div className="flex-shrink-0">
            <div 
              className="text-4xl font-bold text-muted-foreground w-12 text-center transition-colors group-hover:text-foreground" 
              data-testid="text-rank"
              style={{ fontFamily: 'Inter, system-ui, sans-serif', fontWeight: 800 }}
            >
              #{rank}
            </div>
          </div>

          {thumbnail && (
            <div className="flex-shrink-0 relative">
              <div 
                className="w-20 h-20 md:w-24 md:h-24 rounded-lg overflow-hidden bg-muted transition-transform group-hover:scale-105 cursor-pointer relative"
                onClick={() => embedUrl && setShowEmbed(!showEmbed)}
                data-testid="thumbnail-container"
              >
                <img src={thumbnail} alt={title} className="w-full h-full object-cover" data-testid="img-thumbnail" />
                
                {embedUrl && (
                  <div 
                    className="absolute inset-0 bg-black/30 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none"
                    data-testid="play-overlay"
                  >
                    <div className="bg-primary/90 rounded-full p-2">
                      <svg className="w-4 h-4 text-primary-foreground fill-current" viewBox="0 0 24 24">
                        <path d="M8 5v14l11-7z" />
                      </svg>
                    </div>
                  </div>
                )}
              </div>
              
              {externalUrl && (
                <a
                  href={externalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="absolute -top-2 -right-2 bg-background border rounded-full p-1.5 shadow-sm hover-elevate active-elevate-2 transition-all z-10"
                  onClick={(e) => e.stopPropagation()}
                  data-testid="link-external"
                  title="Open in new tab"
                >
                  <ExternalLink className="h-3 w-3 text-muted-foreground" />
                </a>
              )}
            </div>
          )}

          <div className="flex-1 min-w-0">
            <h3 
              className="text-lg font-bold mb-2 transition-colors group-hover:text-primary" 
              data-testid="text-entry-title"
              style={{ fontFamily: 'Inter, system-ui, sans-serif' }}
            >
              {title}
            </h3>

            <p 
              className={`text-sm text-muted-foreground mb-3 leading-relaxed ${!expanded && 'line-clamp-2'}`} 
              data-testid="text-entry-description"
            >
              {description}
            </p>

            <div className="space-y-3">
              <div className="flex flex-wrap items-center gap-4">
                {rating !== undefined && voteCount !== undefined && (
                  <div className="cursor-pointer hover:opacity-80 transition-opacity" onClick={onRate} data-testid="button-rate">
                    <RatingStars rating={rating} voteCount={voteCount} size="sm" variant="stars" />
                  </div>
                )}

                <Button
                  variant="ghost"
                  size="sm"
                  className="gap-2"
                  onClick={onComment}
                  data-testid="button-comment"
                >
                  <MessageCircle className="h-4 w-4" />
                  <span>{commentCount}</span>
                </Button>

                {description.length > 100 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="gap-1"
                    onClick={() => setExpanded(!expanded)}
                    data-testid="button-expand"
                  >
                    {expanded ? (
                      <>
                        <ChevronUp className="h-4 w-4" />
                        Less
                      </>
                    ) : (
                      <>
                        <ChevronDown className="h-4 w-4" />
                        More
                      </>
                    )}
                  </Button>
                )}
              </div>

              {reactions.length > 0 && (
                <EntryReactions 
                  reactions={reactions} 
                  onReact={onReact}
                  size="sm"
                />
              )}
            </div>
          </div>
        </div>

        {showEmbed && embedUrl && (
          <div className="mt-4 pt-4 border-t" data-testid="embed-container">
            <EmbeddedPlayer embedUrl={embedUrl} />
          </div>
        )}
      </div>
    </Card>
  );
}
