interface UpArrowProps {
  className?: string;
  style?: React.CSSProperties;
}

export default function UpArrow({ className = "", style }: UpArrowProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      className={className}
      style={style}
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M12 4L20 12H15V20H9V12H4L12 4Z" fill="#FFA8A8" />
    </svg>
  );
}
