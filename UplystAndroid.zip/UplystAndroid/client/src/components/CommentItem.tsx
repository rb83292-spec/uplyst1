import { useState } from "react";
import { MessageCircle, MoreVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

interface CommentItemProps {
  id: string;
  author: string;
  content: string;
  timestamp: string;
  isModerator?: boolean;
  level?: number;
  onReply?: () => void;
  onDelete?: () => void;
}

export default function CommentItem({
  id,
  author,
  content,
  timestamp,
  isModerator = false,
  level = 0,
  onReply,
  onDelete,
}: CommentItemProps) {
  const [showReply, setShowReply] = useState(false);

  return (
    <div className={`${level > 0 ? 'ml-8 border-l-2 border-border pl-4' : ''}`} data-testid={`comment-${id}`}>
      <div className="flex gap-3">
        <Avatar className="h-8 w-8 flex-shrink-0">
          <AvatarFallback>{author[0].toUpperCase()}</AvatarFallback>
        </Avatar>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-semibold text-sm" data-testid="text-comment-author">
              {author}
            </span>
            {isModerator && (
              <Badge variant="secondary" className="text-xs px-1.5 py-0">
                MOD
              </Badge>
            )}
            <span className="text-xs text-muted-foreground" data-testid="text-comment-timestamp">
              {timestamp}
            </span>
          </div>

          <p className="text-sm mb-2" data-testid="text-comment-content">
            {content}
          </p>

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              className="h-7 text-xs"
              onClick={() => {
                setShowReply(!showReply);
                onReply?.();
              }}
              data-testid="button-reply"
            >
              <MessageCircle className="h-3 w-3 mr-1" />
              Reply
            </Button>

            {isModerator && (
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs text-destructive"
                onClick={onDelete}
                data-testid="button-delete-comment"
              >
                Delete
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
