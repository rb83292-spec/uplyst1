import { useState } from "react";
import { Button } from "@/components/ui/button";
import UpArrow from "./UpArrow";

interface VoteButtonsProps {
  initialVotes: number;
  userVoted?: boolean;
  onVote?: (voted: boolean) => void;
}

export default function VoteButtons({ initialVotes, userVoted: initialUserVoted = false, onVote }: VoteButtonsProps) {
  const [votes, setVotes] = useState(initialVotes);
  const [userVoted, setUserVoted] = useState(initialUserVoted);

  const handleVote = () => {
    const newVoted = !userVoted;
    setVotes(votes + (newVoted ? 1 : -1));
    setUserVoted(newVoted);
    onVote?.(newVoted);
  };

  return (
    <div className="flex flex-col items-center gap-1" data-testid="vote-buttons">
      <Button
        size="icon"
        variant={userVoted ? "default" : "ghost"}
        className="h-8 w-8"
        onClick={handleVote}
        data-testid="button-upvote"
      >
        <UpArrow className="h-5 w-5" />
      </Button>
      
      <span className="text-base font-bold text-foreground" data-testid="text-votes">
        {votes}
      </span>
    </div>
  );
}
