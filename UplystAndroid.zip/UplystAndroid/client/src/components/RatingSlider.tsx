import { useState } from "react";
import { Star } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface RatingSliderProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  entryTitle: string;
  currentRating?: number;
  onSubmit: (rating: number) => void;
}

export default function RatingSlider({
  open,
  onOpenChange,
  entryTitle,
  currentRating,
  onSubmit,
}: RatingSliderProps) {
  const [rating, setRating] = useState(currentRating || 5);

  const handleSubmit = () => {
    onSubmit(rating);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" data-testid="dialog-rating">
        <DialogHeader>
          <DialogTitle>Rate "{entryTitle}"</DialogTitle>
          <DialogDescription>
            Give your rating from 1 to 10
          </DialogDescription>
        </DialogHeader>

        <div className="py-6">
          <div className="flex flex-col items-center gap-6">
            <div className="flex items-center gap-2">
              <Star className="h-12 w-12 fill-rating text-rating" />
              <span className="text-6xl font-bold" data-testid="text-rating-value">
                {rating.toFixed(1)}
              </span>
            </div>

            <Slider
              value={[rating]}
              onValueChange={([value]) => setRating(value)}
              min={1}
              max={10}
              step={0.5}
              className="w-full"
              data-testid="slider-rating"
            />

            <div className="flex w-full justify-between text-xs text-muted-foreground">
              <span>1.0</span>
              <span>5.5</span>
              <span>10.0</span>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} data-testid="button-cancel">
            Cancel
          </Button>
          <Button onClick={handleSubmit} data-testid="button-submit-rating">
            Submit Rating
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
