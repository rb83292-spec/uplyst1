import Footer from '../Footer';

export default function FooterExample() {
  return (
    <div className="min-h-screen flex flex-col">
      <div className="flex-1 p-8 bg-muted/30">
        <h2 className="text-2xl font-bold mb-4">Page Content</h2>
        <p className="text-muted-foreground">
          This is example page content. Scroll down to see the footer.
        </p>
      </div>
      
      <Footer />
    </div>
  );
}
