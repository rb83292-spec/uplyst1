import { useState } from 'react';
import TabNavigation, { TabType } from '../TabNavigation';

export default function TabNavigationExample() {
  const [activeTab, setActiveTab] = useState<TabType>('trending');

  return (
    <TabNavigation
      activeTab={activeTab}
      onTabChange={setActiveTab}
    />
  );
}
