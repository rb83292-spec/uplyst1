import CommentItem from '../CommentItem';

export default function CommentItemExample() {
  return (
    <div className="max-w-2xl space-y-4">
      <CommentItem
        id="1"
        author="filmfan23"
        content="Absolutely amazing list! The Dark Knight deserves the #1 spot without a doubt."
        timestamp="2 hours ago"
        onReply={() => console.log('Reply clicked')}
      />
      
      <div className="space-y-4">
        <CommentItem
          id="2"
          author="moviecritic"
          content="Great selection overall, though I'd argue Inception should be higher."
          timestamp="4 hours ago"
          isModerator={true}
          onReply={() => console.log('Reply clicked')}
          onDelete={() => console.log('Delete clicked')}
        />
        
        <CommentItem
          id="3"
          author="cinephile99"
          content="I agree! It's definitely a top 3 movie in my opinion."
          timestamp="3 hours ago"
          level={1}
          onReply={() => console.log('Reply clicked')}
        />
      </div>
    </div>
  );
}
