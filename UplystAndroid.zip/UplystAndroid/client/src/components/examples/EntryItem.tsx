import EntryItem from '../EntryItem';

export default function EntryItemExample() {
  return (
    <div className="max-w-3xl space-y-4">
      <EntryItem
        rank={1}
        title="The Dark Knight"
        description="When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice. This masterpiece redefined the superhero genre with its complex themes and outstanding performances."
        rating={9.4}
        voteCount={2543}
        commentCount={127}
        onRate={() => console.log('Rate clicked')}
        onComment={() => console.log('Comment clicked')}
      />
      
      <EntryItem
        rank={2}
        title="Inception"
        description="A thief who steals corporate secrets through dream-sharing technology is given the inverse task of planting an idea."
        rating={8.9}
        voteCount={1892}
        commentCount={84}
        onRate={() => console.log('Rate clicked')}
        onComment={() => console.log('Comment clicked')}
      />
    </div>
  );
}
