import { useState } from 'react';
import { Button } from '@/components/ui/button';
import AuthModal from '../AuthModal';

export default function AuthModalExample() {
  const [open, setOpen] = useState(false);

  return (
    <div>
      <Button onClick={() => setOpen(true)}>
        Open Auth Modal
      </Button>
      
      <AuthModal
        open={open}
        onOpenChange={setOpen}
        mode="signin"
      />
    </div>
  );
}
