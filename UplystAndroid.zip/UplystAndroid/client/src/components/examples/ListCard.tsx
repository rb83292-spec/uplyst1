import ListCard from '../ListCard';

export default function ListCardExample() {
  return (
    <div className="max-w-2xl space-y-4">
      <ListCard
        id="1"
        title="Top 50 Songs of 2024"
        description="A curated collection of the most impactful and popular songs that defined the year"
        creator="musiclover42"
        createdAt="2 days ago"
        category="Music"
        entryCount={50}
        votes={342}
        isTrending={true}
        onClick={() => console.log('List clicked')}
      />
      
      <ListCard
        id="2"
        title="Must-Watch Sci-Fi Movies"
        description="Essential science fiction films that every fan should experience"
        creator="filmcritic99"
        createdAt="1 week ago"
        category="Movies"
        entryCount={25}
        votes={128}
        onClick={() => console.log('List clicked')}
      />
    </div>
  );
}
