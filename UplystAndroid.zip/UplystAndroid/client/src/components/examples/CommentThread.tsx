import CommentThread, { Comment } from '../CommentThread';

const mockComments: Comment[] = [
  {
    id: "1",
    author: "musicfan23",
    content: "Absolutely fantastic list! Paint The Town Red is such a deserving #1.",
    timestamp: "2 hours ago",
    isModerator: false,
    replies: [
      {
        id: "2",
        author: "musiclover42",
        content: "Thanks! I spent weeks curating this list to get it just right.",
        timestamp: "1 hour ago",
        isModerator: true,
      },
    ],
  },
  {
    id: "3",
    author: "popsinger99",
    content: "Great selections overall. I'd love to see more indie tracks though!",
    timestamp: "3 hours ago",
    isModerator: false,
    replies: [
      {
        id: "4",
        author: "indiemusic",
        content: "I second this! Would love to see some emerging artists on here.",
        timestamp: "2 hours ago",
        isModerator: false,
      },
      {
        id: "5",
        author: "musiclover42",
        content: "Good suggestion! I'll consider that for the next update.",
        timestamp: "1 hour ago",
        isModerator: true,
      },
    ],
  },
];

export default function CommentThreadExample() {
  return (
    <div className="max-w-3xl p-8">
      <h2 className="text-2xl font-bold mb-6">Comments (2)</h2>
      
      <CommentThread
        comments={mockComments}
        onReply={(commentId) => console.log('Reply to:', commentId)}
        onDelete={(commentId) => console.log('Delete:', commentId)}
      />
    </div>
  );
}
