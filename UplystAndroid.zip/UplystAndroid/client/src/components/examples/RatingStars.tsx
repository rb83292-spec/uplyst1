import RatingStars from '../RatingStars';

export default function RatingStarsExample() {
  return (
    <div className="space-y-4">
      <RatingStars rating={9.2} voteCount={1543} size="lg" />
      <RatingStars rating={7.8} voteCount={432} size="md" />
      <RatingStars rating={6.5} voteCount={89} size="sm" />
    </div>
  );
}
