import { useState } from 'react';
import { Button } from '@/components/ui/button';
import RatingSlider from '../RatingSlider';

export default function RatingSliderExample() {
  const [open, setOpen] = useState(false);

  return (
    <div>
      <Button onClick={() => setOpen(true)}>
        Open Rating Dialog
      </Button>
      
      <RatingSlider
        open={open}
        onOpenChange={setOpen}
        entryTitle="The Dark Knight"
        currentRating={7.5}
        onSubmit={(rating) => console.log('Rating submitted:', rating)}
      />
    </div>
  );
}
