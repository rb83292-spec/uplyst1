import Logo from '../Logo';

export default function LogoExample() {
  return (
    <div className="flex flex-col gap-8 items-center p-8 bg-card rounded-lg">
      <div>
        <p className="text-sm text-muted-foreground mb-4">Small Logo (Header Size)</p>
        <Logo size="sm" showText={true} />
      </div>
      
      <div>
        <p className="text-sm text-muted-foreground mb-4">Medium Logo</p>
        <Logo size="md" showText={true} />
      </div>
      
      <div>
        <p className="text-sm text-muted-foreground mb-4">Large Logo</p>
        <Logo size="lg" showText={true} />
      </div>
      
      <div>
        <p className="text-sm text-muted-foreground mb-4">Icon Only (No Text)</p>
        <Logo size="md" showText={false} />
      </div>
    </div>
  );
}
