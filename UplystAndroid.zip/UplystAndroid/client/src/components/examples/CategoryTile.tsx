import { Music } from 'lucide-react';
import CategoryTile from '../CategoryTile';
import musicBg from '@assets/generated_images/Music_category_background_9ad54aaa.png';

export default function CategoryTileExample() {
  return (
    <CategoryTile
      name="Music"
      count={42}
      backgroundImage={musicBg}
      icon={Music}
      onClick={() => console.log('Music category clicked')}
    />
  );
}
