import TrendingBadge from '../TrendingBadge';

export default function TrendingBadgeExample() {
  return <TrendingBadge />;
}
