import Header from '../Header';

export default function HeaderExample() {
  return (
    <Header
      onAuthClick={() => console.log('Auth clicked')}
      onMenuClick={() => console.log('Menu clicked')}
      isAuthenticated={false}
    />
  );
}
