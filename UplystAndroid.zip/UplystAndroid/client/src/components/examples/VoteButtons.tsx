import VoteButtons from '../VoteButtons';

export default function VoteButtonsExample() {
  return (
    <div className="flex gap-8">
      <VoteButtons initialVotes={42} onVote={(voted) => console.log('Voted:', voted)} />
      <VoteButtons initialVotes={128} userVoted={true} onVote={(voted) => console.log('Voted:', voted)} />
      <VoteButtons initialVotes={256} onVote={(voted) => console.log('Voted:', voted)} />
    </div>
  );
}
