import CommentItem from "./CommentItem";

export interface Comment {
  id: string;
  author: string;
  content: string;
  timestamp: string;
  isModerator?: boolean;
  replies?: Comment[];
}

interface CommentThreadProps {
  comments: Comment[];
  level?: number;
  onReply?: (commentId: string) => void;
  onDelete?: (commentId: string) => void;
}

function CommentWithReplies({ 
  comment, 
  level = 0, 
  onReply, 
  onDelete 
}: { 
  comment: Comment; 
  level?: number;
  onReply?: (commentId: string) => void;
  onDelete?: (commentId: string) => void;
}) {
  return (
    <div className="space-y-4">
      <CommentItem
        id={comment.id}
        author={comment.author}
        content={comment.content}
        timestamp={comment.timestamp}
        isModerator={comment.isModerator}
        level={level}
        onReply={() => onReply?.(comment.id)}
        onDelete={() => onDelete?.(comment.id)}
      />
      
      {comment.replies && comment.replies.length > 0 && (
        <div className={level === 0 ? "ml-12 space-y-4" : "space-y-4"}>
          {comment.replies.map((reply) => (
            <CommentWithReplies
              key={reply.id}
              comment={reply}
              level={level + 1}
              onReply={onReply}
              onDelete={onDelete}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default function CommentThread({
  comments,
  onReply,
  onDelete,
}: CommentThreadProps) {
  return (
    <div className="space-y-6">
      {comments.map((comment) => (
        <CommentWithReplies
          key={comment.id}
          comment={comment}
          level={0}
          onReply={onReply}
          onDelete={onDelete}
        />
      ))}
    </div>
  );
}
