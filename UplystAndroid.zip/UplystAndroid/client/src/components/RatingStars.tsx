import { Star } from "lucide-react";

interface RatingStarsProps {
  rating: number;
  voteCount?: number;
  size?: "sm" | "md" | "lg";
  showCount?: boolean;
  variant?: "numeric" | "stars";
}

export default function RatingStars({ 
  rating, 
  voteCount, 
  size = "md", 
  showCount = true,
  variant = "stars"
}: RatingStarsProps) {
  const sizeClasses = {
    sm: "h-3 w-3",
    md: "h-4 w-4",
    lg: "h-5 w-5",
  };

  const textSizes = {
    sm: "text-sm",
    md: "text-base",
    lg: "text-xl",
  };

  const ratingOutOf5 = rating / 2;
  const fullStars = Math.floor(ratingOutOf5);
  const partialStar = ratingOutOf5 - fullStars;
  const emptyStars = 5 - Math.ceil(ratingOutOf5);

  if (variant === "numeric") {
    return (
      <div className="flex items-center gap-2" data-testid="rating-stars">
        <Star className={`${sizeClasses[size]} fill-rating text-rating`} />
        <span className={`${textSizes[size]} font-bold`} data-testid="text-rating">
          {rating.toFixed(1)}
        </span>
        {showCount && voteCount !== undefined && (
          <span className={`${textSizes[size]} text-muted-foreground`} data-testid="text-vote-count">
            ({voteCount.toLocaleString()})
          </span>
        )}
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2" data-testid="rating-stars">
      <div className="flex items-center gap-0.5">
        {[...Array(fullStars)].map((_, i) => (
          <Star key={`full-${i}`} className={`${sizeClasses[size]} fill-rating text-rating`} />
        ))}
        {partialStar > 0 && (
          <div className="relative" style={{ width: sizeClasses[size].includes('h-3') ? '12px' : sizeClasses[size].includes('h-5') ? '20px' : '16px' }}>
            <Star className={`${sizeClasses[size]} text-muted absolute`} />
            <div className="overflow-hidden absolute inset-0" style={{ width: `${partialStar * 100}%` }}>
              <Star className={`${sizeClasses[size]} fill-rating text-rating`} />
            </div>
          </div>
        )}
        {[...Array(emptyStars)].map((_, i) => (
          <Star key={`empty-${i}`} className={`${sizeClasses[size]} text-muted`} />
        ))}
      </div>
      <span className={`${textSizes[size]} font-bold`} data-testid="text-rating">
        {rating.toFixed(1)}
      </span>
      {showCount && voteCount !== undefined && (
        <span className={`${textSizes[size]} text-muted-foreground`} data-testid="text-vote-count">
          ({voteCount.toLocaleString()})
        </span>
      )}
    </div>
  );
}
