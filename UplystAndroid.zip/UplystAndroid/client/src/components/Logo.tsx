import logoImage from "@assets/7af7ffe0-5148-4136-9184-b3f66ca2a0ac (1)_1762438554571.png";

interface LogoProps {
  size?: "sm" | "md" | "lg";
  showText?: boolean;
}

export default function Logo({ size = "md", showText = true }: LogoProps) {
  const dimensions = {
    sm: { image: "h-8 w-8", text: "text-lg" },
    md: { image: "h-12 w-12", text: "text-2xl" },
    lg: { image: "h-20 w-20", text: "text-4xl" },
  };

  const d = dimensions[size];

  return (
    <div className="flex flex-col items-center gap-1" data-testid="logo">
      <img 
        src={logoImage} 
        alt="Uplyst Logo" 
        className={`${d.image} object-contain`}
      />
      
      {showText && (
        <span className={`${d.text} font-black tracking-tight text-foreground`} data-testid="text-logo">
          UPLYST
        </span>
      )}
    </div>
  );
}
