import { Flame, Clock, TrendingUp } from "lucide-react";

export type TabType = "trending" | "new" | "top";

interface TabNavigationProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

export default function TabNavigation({ activeTab, onTabChange }: TabNavigationProps) {
  const tabs = [
    { id: "trending" as TabType, label: "Trending", icon: Flame },
    { id: "new" as TabType, label: "New", icon: Clock },
    { id: "top" as TabType, label: "Top", icon: TrendingUp },
  ];

  return (
    <div className="border-b bg-background">
      <div className="flex gap-1 px-4 md:px-8">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`
                flex items-center gap-2 px-4 py-3 font-medium transition-colors
                border-b-2 -mb-px
                ${isActive 
                  ? 'border-primary text-primary' 
                  : 'border-transparent text-muted-foreground hover-elevate'
                }
              `}
              data-testid={`button-tab-${tab.id}`}
            >
              <Icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
