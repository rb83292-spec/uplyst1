import { Play } from "lucide-react";
import { cn } from "@/lib/utils";

interface EmbeddedPlayerProps {
  embedUrl: string;
  platform?: "spotify" | "youtube" | "soundcloud" | "generic";
  className?: string;
  onPlay?: () => void;
}

function getEmbedDimensions(platform: string) {
  switch (platform) {
    case "spotify":
      return { width: "100%", height: "152" };
    case "youtube":
      return { width: "100%", height: "315" };
    case "soundcloud":
      return { width: "100%", height: "166" };
    default:
      return { width: "100%", height: "200" };
  }
}

function detectPlatform(url: string): "spotify" | "youtube" | "soundcloud" | "generic" {
  if (url.includes("spotify.com")) return "spotify";
  if (url.includes("youtube.com") || url.includes("youtu.be")) return "youtube";
  if (url.includes("soundcloud.com")) return "soundcloud";
  return "generic";
}

export default function EmbeddedPlayer({
  embedUrl,
  platform,
  className,
  onPlay,
}: EmbeddedPlayerProps) {
  const detectedPlatform = platform || detectPlatform(embedUrl);
  const dimensions = getEmbedDimensions(detectedPlatform);

  return (
    <div
      className={cn(
        "relative w-full rounded-lg overflow-hidden bg-black/90 backdrop-blur-sm",
        className
      )}
      data-testid="embedded-player"
    >
      <div className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none">
        <div className="bg-primary/90 backdrop-blur-sm rounded-full p-4 shadow-lg">
          <Play className="w-8 h-8 text-primary-foreground fill-current" />
        </div>
      </div>

      <iframe
        src={embedUrl}
        width={dimensions.width}
        height={dimensions.height}
        frameBorder="0"
        allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
        loading="lazy"
        className="w-full"
        data-testid="iframe-embed"
        title="Embedded content"
      />
    </div>
  );
}
