import { useState } from "react";
import { Send } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface GuestCommentFormProps {
  onSubmit: (nickname: string, comment: string) => void;
  disabled?: boolean;
}

export default function GuestCommentForm({ onSubmit, disabled }: GuestCommentFormProps) {
  const [nickname, setNickname] = useState("");
  const [comment, setComment] = useState("");
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!nickname.trim() || !comment.trim()) {
      toast({
        title: "Missing information",
        description: "Please enter both a nickname and comment.",
        variant: "destructive",
      });
      return;
    }

    if (comment.length > 200) {
      toast({
        title: "Comment too long",
        description: "Guest comments must be 200 characters or less.",
        variant: "destructive",
      });
      return;
    }

    onSubmit(nickname.trim(), comment.trim());
    setNickname("");
    setComment("");
  };

  return (
    <Card className="p-4" data-testid="form-guest-comment">
      <form onSubmit={handleSubmit} className="space-y-3">
        <div>
          <Input
            placeholder="Your nickname"
            value={nickname}
            onChange={(e) => setNickname(e.target.value)}
            maxLength={30}
            disabled={disabled}
            data-testid="input-guest-nickname"
          />
        </div>
        <div>
          <Input
            placeholder="Share your quick thoughts... (200 chars max)"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            maxLength={200}
            disabled={disabled}
            data-testid="input-guest-comment"
          />
        </div>
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span>Your comment will be moderated before appearing</span>
          <Button
            type="submit"
            size="sm"
            disabled={disabled || !nickname.trim() || !comment.trim()}
            className="gap-2"
            data-testid="button-submit-guest-comment"
          >
            <Send className="h-3 w-3" />
            Post
          </Button>
        </div>
      </form>
    </Card>
  );
}
