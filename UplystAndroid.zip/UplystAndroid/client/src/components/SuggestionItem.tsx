import { useState } from "react";
import { ExternalLink, Check, X } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import SuggestionVoteButtons from "@/components/SuggestionVoteButtons";
import EmbeddedPlayer from "@/components/EmbeddedPlayer";

interface SuggestionItemProps {
  id: string;
  title: string;
  description: string;
  imageUrl?: string;
  externalUrl?: string;
  embedUrl?: string;
  votes: number;
  suggestedBy: string;
  createdAt: string;
  status: "pending" | "community_review" | "approved" | "rejected";
  userVote?: number;
  isModerator?: boolean;
  onVote?: (suggestionId: string, voteType: number) => void;
  onApprove?: (suggestionId: string) => void;
  onReject?: (suggestionId: string) => void;
}

export default function SuggestionItem({
  id,
  title,
  description,
  imageUrl,
  externalUrl,
  embedUrl,
  votes,
  suggestedBy,
  createdAt,
  status,
  userVote,
  isModerator,
  onVote,
  onApprove,
  onReject,
}: SuggestionItemProps) {
  const [showPlayer, setShowPlayer] = useState(false);

  const statusBadges = {
    pending: { label: "Pending Review", variant: "secondary" as const },
    community_review: { label: "Community Review", variant: "default" as const },
    approved: { label: "Approved", variant: "default" as const },
    rejected: { label: "Rejected", variant: "destructive" as const },
  };

  const statusConfig = statusBadges[status];

  return (
    <Card className="p-4 hover-elevate" data-testid={`suggestion-${id}`}>
      <div className="flex gap-4">
        <div className="flex-shrink-0">
          <SuggestionVoteButtons
            initialVotes={votes}
            userVote={userVote}
            onVote={(voteType) => onVote?.(id, voteType)}
            size="sm"
          />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start gap-3 mb-2">
            {imageUrl && (
              <div className="relative flex-shrink-0 w-16 h-16 rounded overflow-hidden">
                <img
                  src={imageUrl}
                  alt={title}
                  className="w-full h-full object-cover"
                />
                {embedUrl && !showPlayer && (
                  <div
                    className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity cursor-pointer"
                    onClick={() => setShowPlayer(true)}
                  >
                    <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center">
                      <div className="w-0 h-0 border-l-8 border-l-black border-y-6 border-y-transparent ml-1" />
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2 mb-1">
                <h4 className="font-semibold text-base" data-testid="text-suggestion-title">
                  {title}
                </h4>
                {externalUrl && (
                  <a
                    href={externalUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-shrink-0"
                    data-testid="link-suggestion-external"
                  >
                    <ExternalLink className="h-4 w-4 text-muted-foreground hover:text-foreground" />
                  </a>
                )}
              </div>

              <p className="text-sm text-muted-foreground mb-2" data-testid="text-suggestion-description">
                {description}
              </p>

              <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                <Badge variant={statusConfig.variant} className="text-xs">
                  {statusConfig.label}
                </Badge>
                <span>Suggested by {suggestedBy}</span>
                <span>•</span>
                <span>{createdAt}</span>
              </div>

              {showPlayer && embedUrl && (
                <div className="mt-3">
                  <EmbeddedPlayer embedUrl={embedUrl} />
                </div>
              )}
            </div>
          </div>

          {isModerator && status !== "approved" && status !== "rejected" && (
            <div className="flex gap-2 mt-3 pt-3 border-t">
              <Button
                size="sm"
                variant="default"
                className="gap-2"
                onClick={() => onApprove?.(id)}
                data-testid="button-approve-suggestion"
              >
                <Check className="h-3 w-3" />
                Approve
              </Button>
              <Button
                size="sm"
                variant="destructive"
                className="gap-2"
                onClick={() => onReject?.(id)}
                data-testid="button-reject-suggestion"
              >
                <X className="h-3 w-3" />
                Reject
              </Button>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}
