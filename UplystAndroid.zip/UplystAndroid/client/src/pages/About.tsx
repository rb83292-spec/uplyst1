import { useState } from "react";
import { Heart, Users, TrendingUp } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import AuthModal from "@/components/AuthModal";
import CreateListModal from "@/components/CreateListModal";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import type { InsertList } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function About() {
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [createListModalOpen, setCreateListModalOpen] = useState(false);
  const { toast } = useToast();

  const handleCreateList = (data: InsertList) => {
    toast({
      title: "List Created!",
      description: `Your ${data.listType} list "${data.title}" has been created.`,
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header
        onAuthClick={() => setAuthModalOpen(true)}
        onCreateListClick={() => setCreateListModalOpen(true)}
        isAuthenticated={false}
      />

      <main className="flex-1 px-4 md:px-8 py-12">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold mb-4" data-testid="text-page-title">
            About Uplyst
          </h1>
          <p className="text-xl text-muted-foreground mb-12">
            Community-driven rankings that help you discover the best in music, movies, tech, and more
          </p>

          <div className="space-y-8 mb-12">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  Our Mission
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Uplyst was created to bring communities together around shared interests. We believe that the best recommendations
                  come from real people with real experiences. Our platform empowers moderators to create curated lists while 
                  giving the community the power to rate, vote, and discuss.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  How It Works
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold mb-2">For Everyone</h3>
                    <p className="text-muted-foreground">
                      Browse curated lists, rate entries on a scale of 1-10, leave reactions, and engage in discussions.
                      Even as a guest, you can explore content and leave limited feedback.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">For Registered Users</h3>
                    <p className="text-muted-foreground">
                      Create an account to unlock unlimited ratings, voting, comments, and the ability to suggest new entries
                      to existing lists. Help shape the community's favorites.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">For Moderators</h3>
                    <p className="text-muted-foreground">
                      Become a moderator to create and manage lists. Curate content across categories like Music, Movies,
                      Tech, Shopping, and more. Review community suggestions and keep your lists fresh and relevant.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  Community-Driven
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  What makes Uplyst special is our community-first approach. We combine expert curation with community feedback
                  to surface the best content. Our suggestion system allows anyone to contribute, while our voting mechanism
                  ensures quality rises to the top.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="border-t pt-8">
            <h2 className="text-2xl font-bold mb-4">Join Our Community</h2>
            <p className="text-muted-foreground mb-6">
              Whether you're here to discover new music, find the perfect app, or share your expertise,
              Uplyst is the place where taste meets community. Sign up today and start exploring!
            </p>
          </div>
        </div>
      </main>

      <Footer />

      <AuthModal
        open={authModalOpen}
        onOpenChange={setAuthModalOpen}
        mode="signin"
        message="Sign in to rate entries and vote on lists"
      />

      <CreateListModal
        open={createListModalOpen}
        onOpenChange={setCreateListModalOpen}
        onSubmit={handleCreateList}
      />
    </div>
  );
}
