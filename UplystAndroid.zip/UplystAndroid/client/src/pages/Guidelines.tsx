import { useState } from "react";
import { Shield, CheckCircle, AlertCircle, Users } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import AuthModal from "@/components/AuthModal";
import CreateListModal from "@/components/CreateListModal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { InsertList } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function Guidelines() {
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [createListModalOpen, setCreateListModalOpen] = useState(false);
  const { toast } = useToast();

  const handleCreateList = (data: InsertList) => {
    toast({
      title: "List Created!",
      description: `Your ${data.listType} list "${data.title}" has been created.`,
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header
        onAuthClick={() => setAuthModalOpen(true)}
        onCreateListClick={() => setCreateListModalOpen(true)}
        isAuthenticated={false}
      />

      <main className="flex-1 px-4 md:px-8 py-12">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold mb-4" data-testid="text-page-title">
            Community Guidelines
          </h1>
          <p className="text-xl text-muted-foreground mb-12">
            Help us maintain a welcoming and respectful community
          </p>

          <div className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  Do's
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Be respectful and kind to all community members</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Provide honest, constructive feedback in ratings and comments</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Suggest relevant entries that add value to lists</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Credit sources when sharing content or information</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Report content that violates our guidelines</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Engage in meaningful discussions and debates</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertCircle className="h-5 w-5 text-red-500" />
                  Don'ts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex gap-2">
                    <span className="text-destructive">•</span>
                    <span>Post spam, promotional content, or irrelevant links</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-destructive">•</span>
                    <span>Harass, bully, or attack other users</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-destructive">•</span>
                    <span>Share inappropriate, offensive, or explicit content</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-destructive">•</span>
                    <span>Manipulate votes or ratings with fake accounts</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-destructive">•</span>
                    <span>Plagiarize or claim others' work as your own</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-destructive">•</span>
                    <span>Share personal information about yourself or others</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-primary" />
                  For Moderators
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  As a moderator, you have additional responsibilities:
                </p>
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Create high-quality, well-curated lists with accurate information</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Review community suggestions fairly and promptly</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Keep your lists updated and remove outdated content</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Respond to community feedback and engage with your audience</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Maintain objectivity and avoid bias in your curation</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  Enforcement
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Violations of these guidelines may result in warnings, temporary suspension, or permanent
                  account termination, depending on the severity. We reserve the right to remove content
                  and take action at our discretion to maintain a safe and welcoming community.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />

      <AuthModal
        open={authModalOpen}
        onOpenChange={setAuthModalOpen}
        mode="signin"
        message="Sign in to rate entries and vote on lists"
      />

      <CreateListModal
        open={createListModalOpen}
        onOpenChange={setCreateListModalOpen}
        onSubmit={handleCreateList}
      />
    </div>
  );
}
