import { useState } from "react";
import { FileText } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import AuthModal from "@/components/AuthModal";
import CreateListModal from "@/components/CreateListModal";
import type { InsertList } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function Terms() {
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [createListModalOpen, setCreateListModalOpen] = useState(false);
  const { toast } = useToast();

  const handleCreateList = (data: InsertList) => {
    toast({
      title: "List Created!",
      description: `Your ${data.listType} list "${data.title}" has been created.`,
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header
        onAuthClick={() => setAuthModalOpen(true)}
        onCreateListClick={() => setCreateListModalOpen(true)}
        isAuthenticated={false}
      />

      <main className="flex-1 px-4 md:px-8 py-12">
        <div className="max-w-4xl mx-auto prose prose-slate dark:prose-invert max-w-none">
          <div className="flex items-center gap-3 mb-4">
            <FileText className="h-8 w-8 text-primary" />
            <h1 className="text-4xl font-bold mb-0" data-testid="text-page-title">
              Terms of Service
            </h1>
          </div>
          <p className="text-sm text-muted-foreground mb-8">Last updated: November 6, 2025</p>

          <div className="space-y-8 text-muted-foreground">
            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">1. Acceptance of Terms</h2>
              <p>
                By accessing and using Uplyst, you accept and agree to be bound by the terms and provision of this agreement.
                If you do not agree to these terms, please do not use our service.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">2. User Accounts</h2>
              <p>
                You may browse Uplyst without an account. However, certain features require registration. When you create
                an account, you agree to:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Provide accurate and complete information</li>
                <li>Maintain the security of your account credentials</li>
                <li>Promptly update your account information if it changes</li>
                <li>Accept responsibility for all activities under your account</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">3. User Content</h2>
              <p>
                You retain ownership of content you submit to Uplyst, including ratings, comments, and suggestions.
                By submitting content, you grant us a non-exclusive, worldwide, royalty-free license to use, display,
                and distribute your content on the platform.
              </p>
              <p className="mt-4">
                You are responsible for your content and must ensure it:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Does not violate any laws or regulations</li>
                <li>Does not infringe on intellectual property rights</li>
                <li>Complies with our Community Guidelines</li>
                <li>Is not spam, offensive, or inappropriate</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">4. Prohibited Activities</h2>
              <p>You may not:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Use the service for any illegal purpose</li>
                <li>Harass, abuse, or harm other users</li>
                <li>Attempt to manipulate votes or ratings</li>
                <li>Create multiple accounts to circumvent restrictions</li>
                <li>Scrape or data mine the platform</li>
                <li>Interfere with the proper functioning of the service</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">5. Intellectual Property</h2>
              <p>
                The Uplyst platform, including its design, features, and content (excluding user-generated content),
                is owned by Uplyst and protected by intellectual property laws. You may not copy, modify, or distribute
                our platform or content without permission.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">6. Termination</h2>
              <p>
                We reserve the right to suspend or terminate your account at any time, with or without notice, for
                violations of these terms or for any other reason we deem appropriate.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">7. Disclaimer</h2>
              <p>
                Uplyst is provided "as is" without warranties of any kind. We do not guarantee the accuracy, completeness,
                or reliability of any content on the platform. Use the service at your own risk.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">8. Limitation of Liability</h2>
              <p>
                Uplyst shall not be liable for any indirect, incidental, special, consequential, or punitive damages
                arising from your use of the service.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">9. Changes to Terms</h2>
              <p>
                We may modify these terms at any time. Continued use of the service after changes constitutes acceptance
                of the new terms. We will notify users of significant changes.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">10. Contact</h2>
              <p>
                If you have questions about these terms, please contact us through our Contact page.
              </p>
            </section>
          </div>
        </div>
      </main>

      <Footer />

      <AuthModal
        open={authModalOpen}
        onOpenChange={setAuthModalOpen}
        mode="signin"
        message="Sign in to rate entries and vote on lists"
      />

      <CreateListModal
        open={createListModalOpen}
        onOpenChange={setCreateListModalOpen}
        onSubmit={handleCreateList}
      />
    </div>
  );
}
