import { useState } from "react";
import { ArrowLeft, Share2, Flag } from "lucide-react";
import { useRoute, useLocation } from "wouter";
import Header from "@/components/Header";
import EntryItem from "@/components/EntryItem";
import VoteButtons from "@/components/VoteButtons";
import RatingSlider from "@/components/RatingSlider";
import AuthModal from "@/components/AuthModal";
import CommentThread, { Comment } from "@/components/CommentThread";
import ListCoverBanner from "@/components/ListCoverBanner";
import GuestCommentForm from "@/components/GuestCommentForm";
import SuggestEntryForm from "@/components/SuggestEntryForm";
import SuggestionItem from "@/components/SuggestionItem";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import TrendingBadge from "@/components/TrendingBadge";
import Footer from "@/components/Footer";
import { useGuestTracking } from "@/hooks/useGuestTracking";
import { useToast } from "@/hooks/use-toast";

//todo: remove mock functionality
const mockListData = {
  id: "1",
  title: "Top 50 Songs of 2024",
  listType: "Top 50",
  description: "A curated collection of the most impactful and popular songs that defined the year. This list features tracks that dominated charts, influenced culture, and showcased artistic excellence.",
  creator: "musiclover42",
  createdAt: "2 days ago",
  category: "Music",
  votes: 342,
  isTrending: true,
  entries: [
    {
      rank: 1,
      title: "Paint The Town Red",
      description: "An infectious pop anthem that dominated the charts with its catchy hook and bold production. The song became a cultural phenomenon on social media.",
      thumbnail: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
      externalUrl: "https://open.spotify.com/track/3rUGC1vUpkDG9CZFHMur1t",
      embedUrl: "https://open.spotify.com/embed/track/3rUGC1vUpkDG9CZFHMur1t?utm_source=generator",
      rating: 9.4,
      voteCount: 2543,
      commentCount: 127,
      reactions: [
        { type: "underrated" as const, count: 287, userReacted: false },
        { type: "overhyped" as const, count: 34, userReacted: false },
      ],
    },
    {
      rank: 2,
      title: "Cruel Summer",
      description: "A synth-pop masterpiece that finally got its moment in the spotlight, showcasing stellar production and emotional depth.",
      thumbnail: "https://images.unsplash.com/photo-1514320291840-2e0a9bf2a9ae?w=300&h=300&fit=crop",
      externalUrl: "https://open.spotify.com/track/1BxfuPKGuaTgP7aM0Bbdwr",
      embedUrl: "https://open.spotify.com/embed/track/1BxfuPKGuaTgP7aM0Bbdwr?utm_source=generator",
      rating: 9.1,
      voteCount: 2198,
      commentCount: 94,
      reactions: [
        { type: "underrated" as const, count: 654, userReacted: false },
        { type: "overhyped" as const, count: 98, userReacted: false },
      ],
    },
    {
      rank: 3,
      title: "Vampire",
      description: "A heart-wrenching ballad that showcases raw vocal talent and vulnerable songwriting.",
      thumbnail: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&h=300&fit=crop",
      externalUrl: "https://open.spotify.com/track/1kuGVB7EU95pJObxwvfwKS",
      embedUrl: "https://open.spotify.com/embed/track/1kuGVB7EU95pJObxwvfwKS?utm_source=generator",
      rating: 8.9,
      voteCount: 1892,
      commentCount: 76,
      reactions: [
        { type: "underrated" as const, count: 543, userReacted: false },
        { type: "overhyped" as const, count: 76, userReacted: false },
      ],
    },
    {
      rank: 4,
      title: "Flowers",
      description: "An empowerment anthem with a disco-inspired sound that resonated worldwide.",
      thumbnail: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop",
      externalUrl: "https://open.spotify.com/track/0yLdNVWF3Srea0uzk55zFn",
      embedUrl: "https://open.spotify.com/embed/track/0yLdNVWF3Srea0uzk55zFn?utm_source=generator",
      rating: 8.7,
      voteCount: 1654,
      commentCount: 52,
      reactions: [
        { type: "underrated" as const, count: 156, userReacted: false },
        { type: "overhyped" as const, count: 234, userReacted: false },
      ],
    },
    {
      rank: 5,
      title: "Snooze",
      description: "A smooth R&B track with dreamy production and captivating vocals.",
      thumbnail: "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=300&h=300&fit=crop",
      externalUrl: "https://open.spotify.com/track/4iZ4pt7kvcaH6Yo8UoZ4s2",
      embedUrl: "https://open.spotify.com/embed/track/4iZ4pt7kvcaH6Yo8UoZ4s2?utm_source=generator",
      rating: 8.5,
      voteCount: 1432,
      commentCount: 41,
      reactions: [
        { type: "underrated" as const, count: 312, userReacted: false },
        { type: "overhyped" as const, count: 45, userReacted: false },
      ],
    },
  ],
};

//todo: remove mock functionality
const mockComments: Comment[] = [
  {
    id: "1",
    author: "musicfan23",
    content: "Absolutely fantastic list! Paint The Town Red is such a deserving #1.",
    timestamp: "2 hours ago",
    isModerator: false,
    replies: [
      {
        id: "2",
        author: "musiclover42",
        content: "Thanks! I spent weeks curating this list to get it just right.",
        timestamp: "1 hour ago",
        isModerator: true,
      },
    ],
  },
  {
    id: "3",
    author: "popsinger99",
    content: "Great selections overall. I'd love to see more indie tracks though!",
    timestamp: "3 hours ago",
    isModerator: false,
  },
];

//todo: remove mock functionality
const mockSuggestions = [
  {
    id: "s1",
    title: "Anti-Hero",
    description: "A massive hit that showcases introspective lyrics and catchy production. Should definitely be included!",
    imageUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
    externalUrl: "https://open.spotify.com/track/0V3wPSX9ygBnCm8psDIegu",
    embedUrl: "https://open.spotify.com/embed/track/0V3wPSX9ygBnCm8psDIegu?utm_source=generator",
    votes: 24,
    suggestedBy: "swiftie94",
    createdAt: "4 days ago",
    status: "community_review" as const,
  },
  {
    id: "s2",
    title: "As It Was",
    description: "Harry Styles' chart-topping single deserves a spot on this list.",
    imageUrl: "https://images.unsplash.com/photo-1514320291840-2e0a9bf2a9ae?w=300&h=300&fit=crop",
    votes: 18,
    suggestedBy: "harryfan21",
    createdAt: "6 days ago",
    status: "community_review" as const,
  },
  {
    id: "s3",
    title: "Calm Down (with Selena Gomez)",
    description: "This collaboration is a global hit and should be recognized.",
    votes: 12,
    suggestedBy: "musicdiscovery",
    createdAt: "3 days ago",
    status: "community_review" as const,
  },
];

export default function ListDetail() {
  const [, params] = useRoute("/list/:id");
  const [, navigate] = useLocation();
  const [ratingModalOpen, setRatingModalOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [selectedEntry, setSelectedEntry] = useState<string | null>(null);
  const [isAuthenticated] = useState(false); //todo: remove mock functionality
  const guestTracking = useGuestTracking();
  const { toast } = useToast();

  const handleRateClick = (entryTitle: string) => {
    if (!isAuthenticated) {
      setAuthModalOpen(true);
    } else {
      setSelectedEntry(entryTitle);
      setRatingModalOpen(true);
    }
  };

  const handleCommentClick = () => {
    if (!isAuthenticated) {
      setAuthModalOpen(true);
    } else {
      console.log('Comment functionality');
    }
  };

  const handleGuestReaction = (entryId: string, reactionType: string) => {
    const currentReaction = guestTracking.getReaction(entryId);
    
    if (currentReaction === reactionType) {
      guestTracking.removeReaction(entryId);
      toast({
        title: "Reaction removed",
        description: "Your reaction has been removed.",
      });
    } else {
      guestTracking.addReaction(entryId, reactionType);
      const reactionLabel = reactionType.charAt(0).toUpperCase() + reactionType.slice(1);
      toast({
        title: "Reaction added",
        description: `You reacted with "${reactionLabel}". Sign up for more features!`,
      });
    }
  };

  const handleGuestComment = (nickname: string, comment: string) => {
    if (!guestTracking.canAddComment()) {
      toast({
        title: "Comment limit reached",
        description: "Guests can only post one comment. Sign up to join the conversation!",
        variant: "destructive",
      });
      return;
    }

    console.log('Guest comment:', { nickname, comment, guestId: guestTracking.guestId });
    guestTracking.incrementCommentCount();
    
    toast({
      title: "Comment submitted",
      description: "Your comment is pending moderation and will appear once approved.",
    });
  };

  const handleSuggestEntry = (suggestion: any) => {
    console.log('Entry suggestion:', suggestion);
  };

  const handleVoteSuggestion = (suggestionId: string, voteType: number) => {
    if (!isAuthenticated) {
      setAuthModalOpen(true);
    } else {
      console.log('Vote on suggestion:', suggestionId, voteType);
    }
  };

  const handleApproveSuggestion = (suggestionId: string) => {
    console.log('Approve suggestion:', suggestionId);
    toast({
      title: "Suggestion approved",
      description: "The suggestion has been added to the list.",
    });
  };

  const handleRejectSuggestion = (suggestionId: string) => {
    console.log('Reject suggestion:', suggestionId);
    toast({
      title: "Suggestion rejected",
      description: "The suggestion has been removed.",
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header
        onAuthClick={() => setAuthModalOpen(true)}
        isAuthenticated={isAuthenticated}
      />

      <main className="flex-1 px-4 md:px-8 py-8">
        <div className="max-w-4xl mx-auto">
          <Button
            variant="ghost"
            onClick={() => navigate("/")}
            className="mb-6 gap-2"
            data-testid="button-back"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Button>

          <ListCoverBanner 
            title={mockListData.title}
            category={mockListData.category}
          />

          <div className="flex gap-6 mb-8">
            <div className="flex-shrink-0">
              <VoteButtons
                initialVotes={mockListData.votes}
                onVote={(voted) => {
                  if (!isAuthenticated) setAuthModalOpen(true);
                  else console.log('List voted:', voted);
                }}
              />
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-start gap-3 mb-3">
                <Badge variant="secondary" data-testid="badge-category">
                  {mockListData.category}
                </Badge>
                {mockListData.isTrending && <TrendingBadge />}
              </div>

              <p className="text-muted-foreground mb-4 text-base leading-relaxed" data-testid="text-list-description">
                {mockListData.description}
              </p>

              <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground mb-4">
                <span data-testid="text-creator">By {mockListData.creator}</span>
                <span>•</span>
                <span data-testid="text-created-at">{mockListData.createdAt}</span>
                <span>•</span>
                <span data-testid="text-entry-count">{mockListData.entries.length} entries</span>
              </div>

              <div className="flex flex-wrap gap-2">
                <SuggestEntryForm
                  listId={mockListData.id}
                  listTitle={mockListData.title}
                  onSubmit={handleSuggestEntry}
                  isAuthenticated={isAuthenticated}
                />
                <Button variant="outline" size="sm" className="gap-2" data-testid="button-share">
                  <Share2 className="h-4 w-4" />
                  Share
                </Button>
                <Button variant="outline" size="sm" className="gap-2" data-testid="button-report">
                  <Flag className="h-4 w-4" />
                  Report
                </Button>
              </div>
            </div>
          </div>

          <Separator className="my-8" />

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-6" style={{ fontFamily: 'Inter, system-ui, sans-serif' }}>Entries</h2>
            
            <div className="space-y-4">
              {mockListData.entries.map((entry) => {
                const entryId = `entry-${entry.rank}`;
                const guestReaction = guestTracking.getReaction(entryId);
                
                const reactionsWithGuest = entry.reactions.map(r => ({
                  ...r,
                  userReacted: isAuthenticated ? r.userReacted : r.type === guestReaction,
                }));

                return (
                  <EntryItem
                    key={entry.rank}
                    {...entry}
                    reactions={reactionsWithGuest}
                    onRate={() => handleRateClick(entry.title)}
                    onComment={handleCommentClick}
                    onReact={(type) => {
                      if (!isAuthenticated) {
                        handleGuestReaction(entryId, type);
                      } else {
                        console.log('Reacted:', type, 'on', entry.title);
                      }
                    }}
                  />
                );
              })}
            </div>
          </section>

          {mockSuggestions.length > 0 && (
            <>
              <Separator className="my-8" />

              <section className="mb-12">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold" style={{ fontFamily: 'Inter, system-ui, sans-serif' }}>
                    Community Suggestions
                  </h2>
                  <Badge variant="secondary" data-testid="badge-suggestions-count">
                    {mockSuggestions.length} pending
                  </Badge>
                </div>

                <p className="text-sm text-muted-foreground mb-6">
                  These entries were suggested by the community and are waiting for approval.
                  Vote to help promote the best suggestions!
                </p>

                <div className="space-y-4">
                  {mockSuggestions.map((suggestion) => (
                    <SuggestionItem
                      key={suggestion.id}
                      {...suggestion}
                      isModerator={false}
                      onVote={handleVoteSuggestion}
                      onApprove={handleApproveSuggestion}
                      onReject={handleRejectSuggestion}
                    />
                  ))}
                </div>
              </section>
            </>
          )}

          <Separator className="my-8" />

          <section>
            <h2 className="text-2xl font-bold mb-6">Comments ({mockComments.length})</h2>
            
            {!isAuthenticated && (
              <div className="mb-6">
                <GuestCommentForm 
                  onSubmit={handleGuestComment}
                  disabled={!guestTracking.canAddComment()}
                />
                {!guestTracking.canAddComment() && (
                  <p className="text-sm text-muted-foreground mt-2 text-center">
                    You've used your guest comment. Sign up to join the conversation!
                  </p>
                )}
              </div>
            )}
            
            <CommentThread
              comments={mockComments}
              onReply={(commentId) => handleCommentClick()}
              onDelete={(commentId) => console.log('Delete comment:', commentId)}
            />
          </section>
        </div>
      </main>

      <Footer />

      <RatingSlider
        open={ratingModalOpen}
        onOpenChange={setRatingModalOpen}
        entryTitle={selectedEntry || ""}
        onSubmit={(rating) => console.log('Rating submitted:', rating)}
      />

      <AuthModal
        open={authModalOpen}
        onOpenChange={setAuthModalOpen}
        mode="signup"
        message="Sign up to rate entries and join the discussion"
      />
    </div>
  );
}
