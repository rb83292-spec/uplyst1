import { useState } from "react";
import { useRoute, useLocation } from "wouter";
import { Music, Film, Palette, Tv, ShoppingBag, Smartphone } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ListCard from "@/components/ListCard";
import TabNavigation, { TabType } from "@/components/TabNavigation";
import AuthModal from "@/components/AuthModal";
import CreateListModal from "@/components/CreateListModal";
import type { InsertList } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

const categoryIcons = {
  music: Music,
  movies: Film,
  artists: Palette,
  streaming: Tv,
  shopping: ShoppingBag,
  tech: Smartphone,
};

//todo: remove mock functionality
const mockLists = [
  {
    id: "1",
    title: "Top 50 Songs of 2024",
    listType: "Top 50",
    description: "A curated collection of the most impactful and popular songs that defined the year",
    creator: "musiclover42",
    createdAt: "2 days ago",
    category: "Music",
    entryCount: 50,
    votes: 342,
    isTrending: true,
    coverImage: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=600&h=400&fit=crop",
  },
  {
    id: "2",
    title: "Most Loved Sci-Fi Movies",
    listType: "Most Loved",
    description: "Science fiction films that have captured the hearts of fans worldwide",
    creator: "filmcritic99",
    createdAt: "1 week ago",
    category: "Movies",
    entryCount: 25,
    votes: 128,
    isTrending: true,
    coverImage: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=600&h=400&fit=crop",
  },
  {
    id: "3",
    title: "Top 20 Productivity Apps 2024",
    listType: "Top 20",
    description: "Tools that will revolutionize your workflow and boost your productivity",
    creator: "techguru",
    createdAt: "3 days ago",
    category: "Tech",
    entryCount: 20,
    votes: 215,
    isTrending: false,
    coverImage: "https://images.unsplash.com/photo-1484788984921-03950022c9ef?w=600&h=400&fit=crop",
  },
  {
    id: "4",
    title: "Top 10 Indie Artists to Watch",
    listType: "Top 10",
    description: "Emerging artists who are pushing creative boundaries",
    creator: "artlover88",
    createdAt: "5 days ago",
    category: "Artists",
    entryCount: 10,
    votes: 89,
    isTrending: false,
    coverImage: "https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=600&h=400&fit=crop",
  },
  {
    id: "5",
    title: "Top Rated Streaming Services",
    listType: "Top Rated",
    description: "The best platforms for entertainment in 2024",
    creator: "streamfan",
    createdAt: "1 day ago",
    category: "Streaming",
    entryCount: 15,
    votes: 167,
    isTrending: true,
    coverImage: "https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?w=600&h=400&fit=crop",
  },
  {
    id: "6",
    title: "Most Loved Online Shopping Sites",
    listType: "Most Loved",
    description: "Where to find the best deals and quality products",
    creator: "shopaholic",
    createdAt: "4 days ago",
    category: "Shopping",
    entryCount: 35,
    votes: 92,
    isTrending: false,
    coverImage: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=600&h=400&fit=crop",
  },
];

export default function Category() {
  const [, params] = useRoute("/category/:name");
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState<TabType>("trending");
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [createListModalOpen, setCreateListModalOpen] = useState(false);
  const { toast } = useToast();

  const categoryName = params?.name || "";
  const categoryTitle = categoryName.charAt(0).toUpperCase() + categoryName.slice(1);
  const Icon = categoryIcons[categoryName.toLowerCase() as keyof typeof categoryIcons] || Music;

  const filteredLists = mockLists.filter(
    list => list.category.toLowerCase() === categoryName.toLowerCase()
  );

  const handleCreateList = (data: InsertList) => {
    toast({
      title: "List Created!",
      description: `Your ${data.listType} list "${data.title}" has been created.`,
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header
        onAuthClick={() => setAuthModalOpen(true)}
        onCreateListClick={() => setCreateListModalOpen(true)}
        isAuthenticated={false}
      />

      <main className="flex-1 px-4 md:px-8 py-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <Icon className="h-8 w-8 text-primary" />
              <h1 className="text-3xl font-bold" data-testid="text-category-title">
                {categoryTitle}
              </h1>
            </div>
            <p className="text-muted-foreground" data-testid="text-category-description">
              Discover the best {categoryTitle.toLowerCase()} lists curated by the community
            </p>
          </div>

          <TabNavigation activeTab={activeTab} onTabChange={setActiveTab} />

          <div className="mt-8">
            {filteredLists.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredLists.map((list) => (
                  <ListCard
                    key={list.id}
                    {...list}
                    thumbnail={list.coverImage}
                    onClick={() => navigate(`/list/${list.id}`)}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-16" data-testid="container-no-lists">
                <Icon className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <h2 className="text-xl font-semibold mb-2">No lists yet</h2>
                <p className="text-muted-foreground">
                  Be the first to create a {categoryTitle.toLowerCase()} list!
                </p>
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />

      <AuthModal
        open={authModalOpen}
        onOpenChange={setAuthModalOpen}
        mode="signin"
        message="Sign in to rate entries and vote on lists"
      />

      <CreateListModal
        open={createListModalOpen}
        onOpenChange={setCreateListModalOpen}
        onSubmit={handleCreateList}
      />
    </div>
  );
}
