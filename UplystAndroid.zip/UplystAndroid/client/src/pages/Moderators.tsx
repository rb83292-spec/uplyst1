import { useState } from "react";
import { Shield, Award, Users } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import AuthModal from "@/components/AuthModal";
import CreateListModal from "@/components/CreateListModal";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import type { InsertList } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function Moderators() {
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [createListModalOpen, setCreateListModalOpen] = useState(false);
  const { toast } = useToast();

  const handleCreateList = (data: InsertList) => {
    toast({
      title: "List Created!",
      description: `Your ${data.listType} list "${data.title}" has been created.`,
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header
        onAuthClick={() => setAuthModalOpen(true)}
        onCreateListClick={() => setCreateListModalOpen(true)}
        isAuthenticated={false}
      />

      <main className="flex-1 px-4 md:px-8 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="h-8 w-8 text-primary" />
            <h1 className="text-4xl font-bold" data-testid="text-page-title">
              Moderators
            </h1>
          </div>
          <p className="text-xl text-muted-foreground mb-12">
            Meet the community leaders who curate and manage Uplyst's lists
          </p>

          <div className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-primary" />
                  What Moderators Do
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Moderators are trusted community members who create and manage curated lists across various categories.
                  Their responsibilities include:
                </p>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Creating high-quality, well-researched lists</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Reviewing and responding to community suggestions</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Keeping lists updated with fresh and relevant content</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Engaging with the community through comments and discussions</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Maintaining the quality and integrity of their lists</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  Becoming a Moderator
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  We're always looking for passionate community members to join our moderator team. Here's what we look for:
                </p>
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold mb-2">Expertise</h3>
                    <p className="text-sm text-muted-foreground">
                      Deep knowledge and passion for a specific category (music, movies, tech, etc.)
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Active Participation</h3>
                    <p className="text-sm text-muted-foreground">
                      Regular engagement with the community through ratings, comments, and suggestions
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Quality Contributions</h3>
                    <p className="text-sm text-muted-foreground">
                      A track record of thoughtful, well-written feedback and suggestions
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Community Spirit</h3>
                    <p className="text-sm text-muted-foreground">
                      Respectful, helpful, and constructive interactions with other users
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Application Process</CardTitle>
                <CardDescription>
                  Interested in becoming a moderator? Here's how to apply
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <div>
                    <h3 className="font-semibold text-foreground mb-2">1. Build Your Profile</h3>
                    <p className="text-sm">
                      Create an account and actively participate in the community. Rate entries, leave thoughtful comments,
                      and suggest valuable additions to existing lists.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-2">2. Demonstrate Expertise</h3>
                    <p className="text-sm">
                      Show your knowledge and passion for a specific category through consistent, high-quality contributions.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-2">3. Contact Us</h3>
                    <p className="text-sm">
                      Once you've established yourself in the community, reach out through our Contact page expressing
                      your interest in becoming a moderator. Include your area of expertise and what kind of lists you'd
                      like to create.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-2">4. Review Process</h3>
                    <p className="text-sm">
                      Our team will review your application and community activity. If approved, you'll receive moderator
                      privileges and can start creating your first list!
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="border-t pt-8">
              <h2 className="text-2xl font-bold mb-4">Meet Our Top Moderators</h2>
              <p className="text-muted-foreground mb-6">
                While our moderator program is still growing, we celebrate the contributors who help make
                Uplyst a trusted source for community-driven recommendations.
              </p>
            </div>
          </div>
        </div>
      </main>

      <Footer />

      <AuthModal
        open={authModalOpen}
        onOpenChange={setAuthModalOpen}
        mode="signin"
        message="Sign in to rate entries and vote on lists"
      />

      <CreateListModal
        open={createListModalOpen}
        onOpenChange={setCreateListModalOpen}
        onSubmit={handleCreateList}
      />
    </div>
  );
}
