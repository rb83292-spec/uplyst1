import { useState } from "react";
import { HelpCircle } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import AuthModal from "@/components/AuthModal";
import CreateListModal from "@/components/CreateListModal";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import type { InsertList } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function FAQ() {
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [createListModalOpen, setCreateListModalOpen] = useState(false);
  const { toast } = useToast();

  const handleCreateList = (data: InsertList) => {
    toast({
      title: "List Created!",
      description: `Your ${data.listType} list "${data.title}" has been created.`,
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header
        onAuthClick={() => setAuthModalOpen(true)}
        onCreateListClick={() => setCreateListModalOpen(true)}
        isAuthenticated={false}
      />

      <main className="flex-1 px-4 md:px-8 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <HelpCircle className="h-8 w-8 text-primary" />
            <h1 className="text-4xl font-bold" data-testid="text-page-title">
              Frequently Asked Questions
            </h1>
          </div>
          <p className="text-xl text-muted-foreground mb-12">
            Find answers to common questions about Uplyst
          </p>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger>What is Uplyst?</AccordionTrigger>
              <AccordionContent>
                Uplyst is a community-driven rankings platform where moderators create curated lists across
                various categories (music, movies, tech, shopping, etc.) and the community can discover,
                rate, vote, and discuss content.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-2">
              <AccordionTrigger>Do I need an account to use Uplyst?</AccordionTrigger>
              <AccordionContent>
                No! You can browse lists and view content as a guest. However, creating an account unlocks
                features like unlimited ratings, voting, commenting, and suggesting new entries to lists.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-3">
              <AccordionTrigger>How do I become a moderator?</AccordionTrigger>
              <AccordionContent>
                Moderator status is currently granted by invitation. We look for active community members
                who consistently provide valuable contributions and demonstrate expertise in specific categories.
                Contact us if you're interested in becoming a moderator.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-4">
              <AccordionTrigger>How does the rating system work?</AccordionTrigger>
              <AccordionContent>
                Users can rate entries on a scale of 1-10. The average rating is displayed as both a numeric
                value and a star rating (out of 5 stars). Each user can only rate an entry once, but can
                update their rating at any time.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-5">
              <AccordionTrigger>What are reactions?</AccordionTrigger>
              <AccordionContent>
                Reactions are quick ways to express your opinion about an entry. We currently have two reactions:
                Underrated (💎) for hidden gems and Overhyped (💡) for content you think gets too much attention.
                Even guests can leave one reaction per entry.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-6">
              <AccordionTrigger>How do community suggestions work?</AccordionTrigger>
              <AccordionContent>
                Registered users can suggest new entries to existing lists. The community can vote on suggestions,
                and moderators can approve or reject them. Suggestions with enough community support may be
                automatically promoted to the main list.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-7">
              <AccordionTrigger>Can I create my own lists?</AccordionTrigger>
              <AccordionContent>
                Currently, only moderators can create and manage lists to ensure quality and consistency.
                However, registered users can suggest entries to existing lists and help shape the content.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-8">
              <AccordionTrigger>How do I report inappropriate content?</AccordionTrigger>
              <AccordionContent>
                If you see content that violates our community guidelines, please contact us through our
                Contact page with details about the content and why it's inappropriate. We review all
                reports promptly.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-9">
              <AccordionTrigger>Is Uplyst free to use?</AccordionTrigger>
              <AccordionContent>
                Yes! Uplyst is completely free to use. You can create an account, rate content, vote, comment,
                and suggest entries without any cost.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-10">
              <AccordionTrigger>How can I contact support?</AccordionTrigger>
              <AccordionContent>
                You can reach us through our Contact page in the footer. We typically respond within 24-48 hours.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </main>

      <Footer />

      <AuthModal
        open={authModalOpen}
        onOpenChange={setAuthModalOpen}
        mode="signin"
        message="Sign in to rate entries and vote on lists"
      />

      <CreateListModal
        open={createListModalOpen}
        onOpenChange={setCreateListModalOpen}
        onSubmit={handleCreateList}
      />
    </div>
  );
}
