import { useState } from "react";
import { ArrowLeft } from "lucide-react";
import { useRoute, useLocation } from "wouter";
import Header from "@/components/Header";
import ListCard from "@/components/ListCard";
import AuthModal from "@/components/AuthModal";
import CreateListModal from "@/components/CreateListModal";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import type { InsertList } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

//todo: remove mock functionality
const categoryLists: Record<string, any[]> = {
  music: [
    {
      id: "1",
      title: "Top 50 Songs of 2024",
      listType: "Top 50",
      description: "A curated collection of the most impactful and popular songs that defined the year",
      creator: "musiclover42",
      createdAt: "2 days ago",
      category: "Music",
      entryCount: 50,
      votes: 342,
      isTrending: true,
    },
    {
      id: "7",
      title: "Top 20 Hip-Hop Albums Ever",
      listType: "Top 20",
      description: "The definitive list of hip-hop albums that shaped the genre",
      creator: "hiphophead",
      createdAt: "1 week ago",
      category: "Music",
      entryCount: 20,
      votes: 256,
      isTrending: false,
    },
  ],
  movies: [
    {
      id: "2",
      title: "Most Loved Sci-Fi Movies",
      listType: "Most Loved",
      description: "Science fiction films that have captured the hearts of fans worldwide",
      creator: "filmcritic99",
      createdAt: "1 week ago",
      category: "Movies",
      entryCount: 25,
      votes: 128,
      isTrending: true,
    },
  ],
  tech: [
    {
      id: "3",
      title: "Top 20 Productivity Apps 2024",
      listType: "Top 20",
      description: "Tools that will revolutionize your workflow and boost your productivity",
      creator: "techguru",
      createdAt: "3 days ago",
      category: "Tech",
      entryCount: 20,
      votes: 215,
      isTrending: false,
    },
  ],
  artists: [
    {
      id: "4",
      title: "Top 10 Indie Artists to Watch",
      listType: "Top 10",
      description: "Emerging artists who are pushing creative boundaries",
      creator: "artlover88",
      createdAt: "5 days ago",
      category: "Artists",
      entryCount: 10,
      votes: 89,
      isTrending: false,
    },
  ],
  streaming: [
    {
      id: "5",
      title: "Top Rated Streaming Services",
      listType: "Top Rated",
      description: "The best platforms for entertainment in 2024",
      creator: "streamfan",
      createdAt: "1 day ago",
      category: "Streaming",
      entryCount: 15,
      votes: 167,
      isTrending: true,
    },
  ],
  shopping: [
    {
      id: "6",
      title: "Most Loved Online Shopping Sites",
      listType: "Most Loved",
      description: "Where to find the best deals and quality products",
      creator: "shopaholic",
      createdAt: "4 days ago",
      category: "Shopping",
      entryCount: 35,
      votes: 92,
      isTrending: false,
    },
  ],
};

export default function CategoryView() {
  const [, params] = useRoute("/category/:category");
  const [, navigate] = useLocation();
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [createListModalOpen, setCreateListModalOpen] = useState(false);
  const { toast } = useToast();

  const categoryName = params?.category || "";
  const lists = categoryLists[categoryName] || [];
  const displayName = categoryName.charAt(0).toUpperCase() + categoryName.slice(1);

  const handleCreateList = (data: InsertList) => {
    toast({
      title: "List Created!",
      description: `Your ${data.listType} list "${data.title}" has been created.`,
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header
        onAuthClick={() => setAuthModalOpen(true)}
        onCreateListClick={() => setCreateListModalOpen(true)}
        isAuthenticated={false}
      />

      <main className="flex-1 px-4 md:px-8 py-8">
        <div className="max-w-6xl mx-auto">
          <Button
            variant="ghost"
            onClick={() => navigate("/")}
            className="mb-6 gap-2"
            data-testid="button-back"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Button>

          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2" data-testid="text-category-name">
              {displayName}
            </h1>
            <p className="text-muted-foreground" data-testid="text-list-count">
              {lists.length} {lists.length === 1 ? 'list' : 'lists'} in this category
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {lists.map((list) => (
              <ListCard
                key={list.id}
                {...list}
                onClick={() => navigate(`/list/${list.id}`)}
              />
            ))}
          </div>

          {lists.length === 0 && (
            <div className="text-center py-16">
              <p className="text-muted-foreground text-lg">
                No lists found in this category yet.
              </p>
            </div>
          )}
        </div>
      </main>

      <Footer />

      <AuthModal
        open={authModalOpen}
        onOpenChange={setAuthModalOpen}
        mode="signin"
      />

      <CreateListModal
        open={createListModalOpen}
        onOpenChange={setCreateListModalOpen}
        onSubmit={handleCreateList}
      />
    </div>
  );
}
