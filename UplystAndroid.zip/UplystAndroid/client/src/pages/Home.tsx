import { useState } from "react";
import { Music, Film, Palette, Tv, ShoppingBag, Smartphone } from "lucide-react";
import Header from "@/components/Header";
import TabNavigation, { TabType } from "@/components/TabNavigation";
import CategoryTile from "@/components/CategoryTile";
import ListCard from "@/components/ListCard";
import AuthModal from "@/components/AuthModal";
import CreateListModal from "@/components/CreateListModal";
import Footer from "@/components/Footer";
import { useLocation } from "wouter";
import type { InsertList } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

import musicBg from '@assets/generated_images/Music_category_background_9ad54aaa.png';
import moviesBg from '@assets/generated_images/Movies_category_background_1ff035db.png';
import artistsBg from '@assets/generated_images/Artists_category_background_2eeaa50b.png';
import streamingBg from '@assets/generated_images/Streaming_category_background_637b3083.png';
import shoppingBg from '@assets/generated_images/Shopping_category_background_521357b1.png';
import techBg from '@assets/generated_images/Tech_category_background_d60f5ce4.png';

//todo: remove mock functionality
const categories = [
  { name: "Music", icon: Music, count: 142, backgroundImage: musicBg },
  { name: "Movies", icon: Film, count: 98, backgroundImage: moviesBg },
  { name: "Artists", icon: Palette, count: 76, backgroundImage: artistsBg },
  { name: "Streaming", icon: Tv, count: 54, backgroundImage: streamingBg },
  { name: "Shopping", icon: ShoppingBag, count: 89, backgroundImage: shoppingBg },
  { name: "Tech", icon: Smartphone, count: 127, backgroundImage: techBg },
];

//todo: remove mock functionality
const mockLists = [
  {
    id: "1",
    title: "Top 50 Songs of 2024",
    listType: "Top 50",
    description: "A curated collection of the most impactful and popular songs that defined the year",
    creator: "musiclover42",
    createdAt: "2 days ago",
    category: "Music",
    entryCount: 50,
    votes: 342,
    isTrending: true,
    coverImage: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=600&h=400&fit=crop",
  },
  {
    id: "2",
    title: "Most Loved Sci-Fi Movies",
    listType: "Most Loved",
    description: "Science fiction films that have captured the hearts of fans worldwide",
    creator: "filmcritic99",
    createdAt: "1 week ago",
    category: "Movies",
    entryCount: 25,
    votes: 128,
    isTrending: true,
    coverImage: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=600&h=400&fit=crop",
  },
  {
    id: "3",
    title: "Top 20 Productivity Apps 2024",
    listType: "Top 20",
    description: "Tools that will revolutionize your workflow and boost your productivity",
    creator: "techguru",
    createdAt: "3 days ago",
    category: "Tech",
    entryCount: 20,
    votes: 215,
    isTrending: false,
    coverImage: "https://images.unsplash.com/photo-1484788984921-03950022c9ef?w=600&h=400&fit=crop",
  },
  {
    id: "4",
    title: "Top 10 Indie Artists to Watch",
    listType: "Top 10",
    description: "Emerging artists who are pushing creative boundaries",
    creator: "artlover88",
    createdAt: "5 days ago",
    category: "Artists",
    entryCount: 10,
    votes: 89,
    isTrending: false,
    coverImage: "https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=600&h=400&fit=crop",
  },
  {
    id: "5",
    title: "Top Rated Streaming Services",
    listType: "Top Rated",
    description: "The best platforms for entertainment in 2024",
    creator: "streamfan",
    createdAt: "1 day ago",
    category: "Streaming",
    entryCount: 15,
    votes: 167,
    isTrending: true,
    coverImage: "https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?w=600&h=400&fit=crop",
  },
  {
    id: "6",
    title: "Most Loved Online Shopping Sites",
    listType: "Most Loved",
    description: "Where to find the best deals and quality products",
    creator: "shopaholic",
    createdAt: "4 days ago",
    category: "Shopping",
    entryCount: 35,
    votes: 92,
    isTrending: false,
    coverImage: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=600&h=400&fit=crop",
  },
];

export default function Home() {
  const [activeTab, setActiveTab] = useState<TabType>("trending");
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [createListModalOpen, setCreateListModalOpen] = useState(false);
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const handleCreateList = (data: InsertList) => {
    toast({
      title: "List Created!",
      description: `Your ${data.listType} list "${data.title}" has been created.`,
    });
  };

  //todo: remove mock functionality
  const filteredLists = mockLists
    .filter(list => {
      if (activeTab === "trending") return list.isTrending;
      return true;
    })
    .sort((a, b) => {
      if (activeTab === "top") return b.votes - a.votes;
      if (activeTab === "new") return 0;
      return b.votes - a.votes;
    });

  return (
    <div className="min-h-screen flex flex-col">
      <Header
        onAuthClick={() => setAuthModalOpen(true)}
        onCreateListClick={() => setCreateListModalOpen(true)}
        isAuthenticated={false}
      />

      <TabNavigation activeTab={activeTab} onTabChange={setActiveTab} />

      <main className="flex-1 px-4 md:px-8 py-8">
        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-3xl font-bold">Explore Categories</h2>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((category) => (
              <CategoryTile
                key={category.name}
                name={category.name}
                count={category.count}
                backgroundImage={category.backgroundImage}
                icon={category.icon}
                onClick={() => navigate(`/category/${category.name.toLowerCase()}`)}
              />
            ))}
          </div>
        </section>

        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-3xl font-bold">
              {activeTab === "trending" && "Trending Lists"}
              {activeTab === "new" && "Recently Created"}
              {activeTab === "top" && "Top Rated Lists"}
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 max-w-7xl">
            {filteredLists.map((list) => (
              <ListCard
                key={list.id}
                {...list}
                thumbnail={list.coverImage}
                onClick={() => navigate(`/list/${list.id}`)}
              />
            ))}
          </div>
        </section>
      </main>

      <Footer />

      <AuthModal
        open={authModalOpen}
        onOpenChange={setAuthModalOpen}
        mode="signin"
        message="Sign in to rate entries and vote on lists"
      />

      <CreateListModal
        open={createListModalOpen}
        onOpenChange={setCreateListModalOpen}
        onSubmit={handleCreateList}
      />
    </div>
  );
}
