import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/Home";
import ListDetail from "@/pages/ListDetail";
import Category from "@/pages/Category";
import SearchResults from "@/pages/SearchResults";
import About from "@/pages/About";
import Guidelines from "@/pages/Guidelines";
import Moderators from "@/pages/Moderators";
import FAQ from "@/pages/FAQ";
import Terms from "@/pages/Terms";
import Privacy from "@/pages/Privacy";
import Contact from "@/pages/Contact";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/list/:id" component={ListDetail} />
      <Route path="/category/:name" component={Category} />
      <Route path="/search" component={SearchResults} />
      <Route path="/about" component={About} />
      <Route path="/guidelines" component={Guidelines} />
      <Route path="/moderators" component={Moderators} />
      <Route path="/faq" component={FAQ} />
      <Route path="/terms" component={Terms} />
      <Route path="/privacy" component={Privacy} />
      <Route path="/contact" component={Contact} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Router />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}
