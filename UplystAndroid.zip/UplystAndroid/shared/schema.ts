import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, pgEnum, numeric, boolean, index, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export const listTypeEnum = pgEnum("list_type", ["Top 50", "Top 20", "Top 10", "Top Rated", "Most Loved"]);
export const listTypes = ["Top 50", "Top 20", "Top 10", "Top Rated", "Most Loved"] as const;
export type ListType = typeof listTypes[number];

export const reactionTypeEnum = pgEnum("reaction_type", ["underrated", "overhyped"]);
export const reactionTypes = ["underrated", "overhyped"] as const;
export type ReactionType = typeof reactionTypes[number];

export const lists = pgTable("lists", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  listType: listTypeEnum("list_type").notNull(),
  category: text("category").notNull(),
  coverImage: text("cover_image"),
  createdBy: varchar("created_by").notNull(),
  votes: integer("votes").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertListSchema = createInsertSchema(lists).omit({
  id: true,
  votes: true,
  createdAt: true,
}).extend({
  listType: z.enum(listTypes),
});

export type InsertList = z.infer<typeof insertListSchema>;
export type List = typeof lists.$inferSelect;

export const listEntries = pgTable("list_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  listId: varchar("list_id").notNull().references(() => lists.id),
  rank: integer("rank").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  externalUrl: text("external_url"),
  embedUrl: text("embed_url"),
  averageRating: numeric("average_rating", { precision: 3, scale: 1 }).default("0"),
  totalRatings: integer("total_ratings").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertListEntrySchema = createInsertSchema(listEntries).omit({
  id: true,
  averageRating: true,
  totalRatings: true,
  createdAt: true,
});

export type InsertListEntry = z.infer<typeof insertListEntrySchema>;
export type ListEntry = typeof listEntries.$inferSelect;

export const entryReactions = pgTable("entry_reactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  entryId: varchar("entry_id").notNull().references(() => listEntries.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  reactionType: reactionTypeEnum("reaction_type").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertEntryReactionSchema = createInsertSchema(entryReactions).omit({
  id: true,
  createdAt: true,
}).extend({
  reactionType: z.enum(reactionTypes),
});

export type InsertEntryReaction = z.infer<typeof insertEntryReactionSchema>;
export type EntryReaction = typeof entryReactions.$inferSelect;

export const entryComments = pgTable("entry_comments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  entryId: varchar("entry_id").notNull().references(() => listEntries.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  comment: text("comment").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertEntryCommentSchema = createInsertSchema(entryComments).omit({
  id: true,
  createdAt: true,
});

export type InsertEntryComment = z.infer<typeof insertEntryCommentSchema>;
export type EntryComment = typeof entryComments.$inferSelect;

export const guestReactions = pgTable("guest_reactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  entryId: varchar("entry_id").notNull().references(() => listEntries.id),
  guestId: varchar("guest_id").notNull(),
  reactionType: reactionTypeEnum("reaction_type").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertGuestReactionSchema = createInsertSchema(guestReactions).omit({
  id: true,
  createdAt: true,
}).extend({
  reactionType: z.enum(reactionTypes),
});

export type InsertGuestReaction = z.infer<typeof insertGuestReactionSchema>;
export type GuestReaction = typeof guestReactions.$inferSelect;

export const moderationStatusEnum = pgEnum("moderation_status", ["pending", "approved", "rejected"]);

export const guestComments = pgTable("guest_comments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  entryId: varchar("entry_id").notNull().references(() => listEntries.id),
  guestId: varchar("guest_id").notNull(),
  nickname: varchar("nickname").notNull(),
  comment: text("comment").notNull(),
  moderationStatus: moderationStatusEnum("moderation_status").default("pending").notNull(),
  linkedUserId: varchar("linked_user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertGuestCommentSchema = createInsertSchema(guestComments).omit({
  id: true,
  moderationStatus: true,
  linkedUserId: true,
  createdAt: true,
});

export type InsertGuestComment = z.infer<typeof insertGuestCommentSchema>;
export type GuestComment = typeof guestComments.$inferSelect;

export const suggestionStatusEnum = pgEnum("suggestion_status", ["pending", "community_review", "approved", "rejected"]);

export const suggestions = pgTable("suggestions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  listId: varchar("list_id").notNull().references(() => lists.id),
  suggestedBy: varchar("suggested_by").notNull().references(() => users.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  externalUrl: text("external_url"),
  embedUrl: text("embed_url"),
  status: suggestionStatusEnum("status").default("pending").notNull(),
  votes: integer("votes").default(0).notNull(),
  rank: integer("rank"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  reviewedAt: timestamp("reviewed_at"),
  promotedAt: timestamp("promoted_at"),
});

export const insertSuggestionSchema = createInsertSchema(suggestions).omit({
  id: true,
  status: true,
  votes: true,
  rank: true,
  createdAt: true,
  reviewedAt: true,
  promotedAt: true,
});

export type InsertSuggestion = z.infer<typeof insertSuggestionSchema>;
export type Suggestion = typeof suggestions.$inferSelect;

export const suggestionVotes = pgTable("suggestion_votes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  suggestionId: varchar("suggestion_id").notNull().references(() => suggestions.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  voteType: integer("vote_type").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSuggestionVoteSchema = createInsertSchema(suggestionVotes).omit({
  id: true,
  createdAt: true,
});

export type InsertSuggestionVote = z.infer<typeof insertSuggestionVoteSchema>;
export type SuggestionVote = typeof suggestionVotes.$inferSelect;
